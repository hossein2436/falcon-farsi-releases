/* service worker: تزریق هسته + بررسی و دریافت به‌روزرسانی از گیت‌هاب */
importScripts("config.js");
const C = self.FX_CONFIG;
const RAW = (ref, path) => `https://raw.githubusercontent.com/${C.owner}/${C.repo}/${ref}/${path}`;

/* ---------- هسته‌ی فعلی: نسخه‌ی دانلودشده، یا نسخه‌ی داخل خود افزونه */
async function bundledCore() {
  const get = (p) => fetch(chrome.runtime.getURL(p)).then((r) => (p.endsWith(".json") ? r.json() : r.text()));
  const [meta, css, js] = await Promise.all([get("core/version.json"), get("core/content.css"), get("core/core.js")]);
  return { version: meta.version, notes: meta.notes || "", css, js, source: "bundled" };
}
async function currentCore() {
  const { core } = await chrome.storage.local.get("core");
  const bundled = await bundledCore();
  // اگر نسخه‌ی داخلِ zip جدیدتر از کش باشد، همان را استفاده کن
  if (core && cmp(core.version, bundled.version) >= 0) return core;
  return bundled;
}

/* ---------- مقایسه‌ی نسخه */
function cmp(a, b) {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}

/* ---------- تزریق */
async function inject(tabId, frameId) {
  const core = await currentCore();
  const css = core.css.replace(/__MSG_@@extension_id__/g, chrome.runtime.id);
  const target = { tabId, frameIds: [frameId || 0] };
  await chrome.scripting.insertCSS({ target, css, origin: "AUTHOR" });
  await chrome.scripting.executeScript({
    target, world: "MAIN", injectImmediately: true,
    func: (code) => { if (!window.__fxLoaded) (0, eval)(code); },
    args: [core.js],
  });
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "fx:boot" && sender.tab) {
    inject(sender.tab.id, sender.frameId).then(() => reply({ ok: true }), (e) => reply({ ok: false, error: String(e) }));
    return true;
  }
  if (msg && msg.type === "fx:status") { status().then(reply); return true; }
  if (msg && msg.type === "fx:check") { check().then(reply, (e) => reply({ error: String(e.message || e) })); return true; }
  if (msg && msg.type === "fx:update") { update().then(reply, (e) => reply({ error: String(e.message || e) })); return true; }
});

/* ---------- گیت‌هاب */
async function latestRef() {
  // sha آخرین کامیت → دور زدن کش CDN گیت‌هاب
  try {
    const r = await fetch(`https://api.github.com/repos/${C.owner}/${C.repo}/commits/${C.branch}`, { cache: "no-store", headers: { Accept: "application/vnd.github+json" } });
    if (r.ok) return (await r.json()).sha;
  } catch (e) { /* محدودیت نرخ API → از شاخه استفاده می‌کنیم */ }
  return C.branch;
}
async function remoteMeta() {
  const ref = await latestRef();
  const r = await fetch(RAW(ref, "version.json") + (ref === C.branch ? `?t=${Date.now()}` : ""), { cache: "no-store" });
  if (!r.ok) throw new Error(`version.json در دسترس نیست (${r.status})`);
  return { ref, meta: await r.json() };
}
async function status() {
  const core = await currentCore();
  const { lastCheck } = await chrome.storage.local.get("lastCheck");
  return { version: core.version, notes: core.notes, source: core.source, updatedAt: core.updatedAt || null, lastCheck: lastCheck || null, loaderVersion: C.loaderVersion, extVersion: chrome.runtime.getManifest().version };
}
async function check() {
  const [{ ref, meta }, core] = await Promise.all([remoteMeta(), currentCore()]);
  const lastCheck = { at: Date.now(), remote: meta.version, notes: meta.notes || "", minLoader: meta.minLoader || 1, ref };
  await chrome.storage.local.set({ lastCheck });
  const available = cmp(meta.version, core.version) > 0;
  const loaderTooOld = (meta.minLoader || 1) > C.loaderVersion;
  setBadge(available);
  return { current: core.version, remote: meta.version, notes: meta.notes || "", available, loaderTooOld, zipUrl: meta.zip || null };
}
async function update() {
  const { ref, meta } = await remoteMeta();
  if ((meta.minLoader || 1) > C.loaderVersion) throw new Error("این نسخه به لودر جدید نیاز دارد؛ zip تازه را نصب کنید.");
  const get = async (p) => { const r = await fetch(RAW(ref, p), { cache: "no-store" }); if (!r.ok) throw new Error(`${p}: ${r.status}`); return r.text(); };
  const [css, js] = await Promise.all([get("content.css"), get("core.js")]);
  if (!js.includes("__fxLoaded") || css.length < 1000) throw new Error("فایل‌های دریافتی ناقص‌اند");
  const core = { version: meta.version, notes: meta.notes || "", css, js, source: "github", ref, updatedAt: Date.now() };
  await chrome.storage.local.set({ core, lastCheck: { at: Date.now(), remote: meta.version, notes: core.notes, ref } });
  setBadge(false);
  const tabs = await chrome.tabs.query({ url: "https://falcon.snappfood.dev/*" });
  tabs.forEach((t) => chrome.tabs.reload(t.id));
  return { ok: true, version: meta.version, reloaded: tabs.length };
}

/* ---------- نشان روی آیکون + بررسی دوره‌ای */
function setBadge(on) {
  chrome.action.setBadgeText({ text: on ? "نو" : "" });
  chrome.action.setBadgeBackgroundColor({ color: "#e8b450" });
  if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: "#08102b" });
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("fx-check", { periodInMinutes: C.checkEveryMinutes, delayInMinutes: 1 });
});
chrome.runtime.onStartup.addListener(() => { check().catch(() => {}); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "fx-check") check().catch(() => {}); });
