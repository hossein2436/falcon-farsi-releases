/* لودر: تنظیمات را به هسته می‌دهد و از background می‌خواهد هسته را تزریق کند.
   هسته (CSS + JS) از chrome.storage.local می‌آید و با دکمه‌ی به‌روزرسانی عوض می‌شود.
   تنظیمات هم روی <html data-fx-settings> (برای لحظه‌ی بوت) و هم در detail رویداد fx:settings فرستاده می‌شوند،
   چون ری‌اکت هنگام hydration ممکن است attributeهای ناشناخته‌ی <html> را پاک کند. */
(() => {
  const DEFAULTS = { enabled: true, theme: "auto", translate: true, digits: true, rtl: true, motion: true };
  const root = document.documentElement;
  let current = DEFAULTS;

  const send = () => {
    const json = JSON.stringify(current);
    root.setAttribute("data-fx-settings", json);
    document.dispatchEvent(new CustomEvent("fx:settings", { detail: json }));
  };

  chrome.storage.sync.get(DEFAULTS, (s) => {
    current = { ...DEFAULTS, ...s };
    root.setAttribute("data-fx-settings", JSON.stringify(current));
    chrome.runtime.sendMessage({ type: "fx:boot" }, () => { void chrome.runtime.lastError; send(); });
  });

  // هسته وقتی آماده شد سلام می‌کند؛ تنظیمات را دوباره بفرست
  document.addEventListener("fx:hello", send);

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "sync") return;
    chrome.storage.sync.get(DEFAULTS, (s) => { current = { ...DEFAULTS, ...s }; send(); });
  });
})();
