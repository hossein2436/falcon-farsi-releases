/* لودر: تنظیمات را روی <html> می‌گذارد و از background می‌خواهد هسته را تزریق کند.
   خودِ هسته (CSS + JS) از chrome.storage.local می‌آید و با دکمه‌ی به‌روزرسانی عوض می‌شود. */
(() => {
  const DEFAULTS = { enabled: true, theme: "night", translate: true, digits: true, rtl: true, motion: true };
  const root = document.documentElement;

  function push(settings, notify) {
    root.setAttribute("data-fx-settings", JSON.stringify({ ...DEFAULTS, ...settings }));
    if (notify) document.dispatchEvent(new CustomEvent("fx:settings"));
  }

  chrome.storage.sync.get(DEFAULTS, (s) => {
    push(s, false);
    // قبل از رسیدن CSS، رنگ پس‌زمینه را بگذار تا صفحه‌ی سفید چشمک نزند
    if (s.enabled) root.style.setProperty("background", s.theme === "day" ? "#f6efe1" : "#08102b");
    chrome.runtime.sendMessage({ type: "fx:boot" }, () => {
      void chrome.runtime.lastError;
      root.style.removeProperty("background");
    });
  });

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "sync") return;
    chrome.storage.sync.get(DEFAULTS, (s) => push(s, true));
  });
})();
