/* falcon-farsi core v2.0.0 */
/* فالکون · پوسته‌ی فارسی — فرهنگ واژه‌ها (v2)
   کلید: متن انگلیسی با حروف کوچک و فاصله‌ی یکسان. اصطلاحات جاافتاده (CR، Close Cart، Supertype، Gem، Off-Box،
   Meal For One، Retention، Funnel، RCA، pp/pt، نام پلتفرم‌ها و رویدادها) عمداً انگلیسی می‌مانند. */
window.FF_DICT = {
  /* ── برند و ناوبری ───────────────────────────── */
  "falcon": "فالکون",
  "conversion & behavioral": "هوش تبدیل و رفتار کاربر",
  "intelligence": "اسنپ‌فود",
  "conversion & behavioral intelligence": "هوش تبدیل و رفتار کاربر",
  "main": "منوی اصلی",
  "executive": "مدیریتی",
  "control center": "مرکز کنترل",
  "overall funnel": "قیف کلی",
  "funnel intelligence": "هوش قیف",
  "entry channels": "کانال‌های ورود",
  "macro funnels": "قیف‌های کلان",
  "search-led": "جست‌وجومحور",
  "search": "جست‌وجو",
  "browse": "مرور",
  "supertype": "Supertype",
  "category": "دسته‌بندی",
  "discount tools": "ابزارهای تخفیف",
  "gem": "Gem",
  "party": "پارتی",
  "off-box": "Off-Box",
  "services": "سرویس‌ها",
  "meal for one": "Meal For One",
  "eco": "Eco",
  "landing": "لندینگ",
  "sponsored": "اسپانسری",
  "retention": "بازگشتی‌ها",
  "orders": "سفارش‌ها",
  "funnel explorer": "کاوشگر قیف",
  "home heatmap": "هیت‌مپ خانه",
  "incrementality": "اثر افزایشی",
  "funnel rca engine": "موتور RCA قیف",
  "journey rca": "RCA مسیرها",
  "deep dives": "تحلیل عمیق",
  "hourly & shifts": "ساعتی و شیفت‌ها",
  "cities": "شهرها",
  "marketing areas": "مناطق مارکتینگ",
  "platforms": "پلتفرم‌ها",
  "monitoring": "پایش",
  "alert center": "مرکز هشدار",
  "incident intelligence": "هوش رخداد",
  "action tracker": "پیگیری اقدام‌ها",
  "change log": "تاریخچه‌ی تغییرات",
  "shock monitor": "پایش شوک",
  "synthetic monitoring": "پایش Synthetic",
  "administration": "مدیریت سامانه",
  "access": "دسترسی",
  "users & access": "کاربران و دسترسی",
  "ownership": "مالکیت",
  "data": "داده",
  "data ingestion": "ورود داده",
  "calendar pulse": "نبض تقویم",
  "funnel registry": "رجیستری قیف‌ها",
  "alert rules": "قوانین هشدار",
  "notifications": "اعلان‌ها",
  "email recipients": "گیرندگان ایمیل",
  "news events": "رویدادهای خبری",
  "audit log": "لاگ ممیزی",
  "system": "سیستم",
  "settings": "تنظیمات",
  "close the menu": "بستن منو",
  "open menu": "باز کردن منو",
  "expand macro funnels": "باز کردن قیف‌های کلان",
  "collapse macro funnels": "بستن قیف‌های کلان",
  "what is happening": "چه خبر است",
  "where conversion is changing": "نرخ تبدیل کجا تغییر می‌کند",
  "why, through what intent, users entered": "کاربران با چه نیتی وارد شدند",
  "which program produced the path": "کدام برنامه مسیر خرید را ساخت",
  "entry point to landing, cart, checkout and order": "از نقطه‌ی ورود تا لندینگ، سبد، پرداخت و سفارش",
  "where users tap on the home screen (real clicks)": "کاربران کجای صفحه‌ی خانه را لمس می‌کنند (کلیک واقعی)",
  "what a launch added, and what it took from other services": "یک لانچ چه اضافه کرد و از سرویس‌های دیگر چه گرفت",
  "which stages and segments explain a drop in orders / sessions": "کدام مرحله‌ها و بخش‌ها افت سفارش به سشن را توضیح می‌دهند",
  "which entry journeys, platforms and steps explain a change in conversion": "کدام مسیرهای ورود، پلتفرم‌ها و مرحله‌ها تغییر نرخ تبدیل را توضیح می‌دهند",
  "carousel funnel dashboard": "داشبورد قیف کاروسل",
  "when conversion happens": "نرخ تبدیل چه ساعتی اتفاق می‌افتد",
  "which cities need attention": "کدام شهرها توجه می‌خواهند",
  "where the opportunity is": "فرصت کجاست",
  "sessions and orders per platform (pwa, apps, super app)": "سشن و سفارش هر پلتفرم (PWA، اپ‌ها، سوپراپ)",
  "detected anomalies & ownership": "ناهنجاری‌های شناسایی‌شده و مالکیت",
  "orders lost to a site incident, minute by minute": "سفارش‌های ازدست‌رفته در رخداد سایت، دقیقه به دقیقه",
  "who does what about a finding, and whether it worked": "چه کسی برای یک یافته چه می‌کند و آیا اثر داشت",
  "releases, rollouts and campaigns, measured before and after": "ریلیزها، رول‌اوت‌ها و کمپین‌ها، قبل و بعد",
  "external events vs. conversion": "رویدادهای بیرونی در برابر نرخ تبدیل",
  "is the site working for users right now (separate dashboard)": "سایت همین حالا برای کاربران کار می‌کند؟ (داشبورد جدا)",

  /* ── سربرگ ───────────────────────────── */
  "view as": "نمایش برای",
  "brief": "خلاصه",
  "mission control": "اتاق فرمان",
  "cockpit": "کاکپیت",
  "light theme": "تم روشن",
  "dark theme": "تم تیره",
  "switch to light theme": "رفتن به تم روشن",
  "switch to dark theme": "رفتن به تم تیره",
  "switch to gregorian dates": "تاریخ میلادی",
  "switch to shamsi dates": "تاریخ شمسی",
  "live": "زنده",
  "open data assistant": "دستیار داده",
  "where this page's data comes from": "منبع داده‌های این صفحه",
  "breadcrumb": "مسیر صفحه",
  "loading": "در حال بارگذاری",
  "loading…": "در حال بارگذاری…",
  "loading...": "در حال بارگذاری…",
  "measuring…": "در حال اندازه‌گیری…",
  "analysing…": "در حال تحلیل…",

  /* ── مرکز کنترل: CEO ───────────────────────────── */
  "expand ⤢": "بزرگ‌نمایی ⤢",
  "expand": "بزرگ‌نمایی",
  "watch": "زیر نظر",
  "healthy": "سالم",
  "warning": "هشدار",
  "at risk": "در خطر",
  "critical": "بحرانی",
  "record": "رکورد",
  "look first": "اول اینجا را ببین",
  "today so far": "امروز تا این لحظه",
  "partial day": "روز ناقص",
  "data stored": "داده ذخیره شد",
  "conversion": "نرخ تبدیل",
  "valid sessions": "سشن‌های معتبر",
  "revenue": "درآمد",
  "revenue yesterday": "درآمد دیروز",
  "orders yesterday": "سفارش‌های دیروز",
  "conversion (close-cart)": "نرخ تبدیل (Close Cart)",
  "orders vs expected": "سفارش در برابر انتظار",
  "paid orders": "سفارش‌های پرداخت‌شده",
  "traffic by platform": "ترافیک به تفکیک پلتفرم",
  "share of sessions by platform, against its usual share.": "سهم هر پلتفرم از سشن‌ها، در برابر سهم معمولش.",
  "share of sessions by platform": "سهم پلتفرم‌ها از سشن‌ها",
  "how users enter": "کاربران از کجا وارد می‌شوند",
  "share of sessions by entry channel.": "سهم سشن‌ها به تفکیک کانال ورود.",
  "share of sessions by entry channel": "سهم سشن‌ها به تفکیک کانال ورود",
  "where": "کجا",
  "provinces by traffic; hover for sessions and conversion.": "استان‌ها بر اساس ترافیک؛ برای دیدن سشن و نرخ تبدیل، نشانگر را روی استان ببرید.",
  "map of iran, provinces by sessions": "نقشه‌ی ایران، استان‌ها بر اساس سشن",
  "map of iran with city conversion change": "نقشه‌ی ایران با تغییر نرخ تبدیل شهرها",
  "needs attention": "نیازمند توجه",
  "the biggest moves, ranked by orders.": "بزرگ‌ترین تغییرها، به ترتیب اثر روی سفارش.",
  "last 30 days": "۳۰ روز اخیر",
  "close-cart sessions (bars), their conversion (line) and gross-order conversion (dashed), complete days only.": "سشن‌های Close Cart (ستون)، نرخ تبدیلشان (خط) و نرخ تبدیل سفارش ناخالص (خط‌چین)؛ فقط روزهای کامل.",
  "orders (close-cart sessions)": "سفارش (سشن‌های Close Cart)",
  "orders and conversion trend": "روند سفارش و نرخ تبدیل",
  "revenue by path": "درآمد به تفکیک مسیر",
  "who brought in the most money on the day.": "کدام مسیر آن روز بیشترین درآمد را ساخت.",
  "revenue by service": "درآمد به تفکیک سرویس",
  "experiments": "آزمایش‌ها",
  "conversion vs control, 7 days up to now.": "نرخ تبدیل در برابر گروه کنترل، ۷ روز تا امروز.",
  "share of sessions that ordered, each variation against the control, last 7 days. exposure, not a randomised proof.": "سهم سشن‌هایی که سفارش دادند، هر واریانت در برابر کنترل، ۷ روز اخیر. این مواجهه است، نه اثبات تصادفی‌سازی‌شده.",
  "today, live": "امروز، زنده",
  "yesterday, complete": "دیروز، کامل",
  "sessions": "سشن‌ها",
  "variation": "واریانت",
  "vs control:": "در برابر کنترل:",
  "no clear difference": "تفاوت روشنی ندارد",
  "better": "بهتر",
  "worse": "بدتر",
  "control": "کنترل",
  "engineered by platform team @2026": "ساخته‌ی تیم پلتفرم · ۲۰۲۶",
  "clearly below usual": "به‌وضوح زیر معمول",
  "clearly above usual": "به‌وضوح بالای معمول",
  "within its normal range": "در بازه‌ی معمول",
  "dot size = sessions": "اندازه‌ی نقطه = سشن",
  "too few sessions": "سشن کافی نیست",
  "cell = order rate of sessions that visited the entry page.": "هر خانه = نرخ سفارشِ سشن‌هایی که صفحه‌ی ورود را دیدند.",
  "red or green = change against the previous window.": "قرمز یا سبز = تغییر نسبت به بازه‌ی قبل.",
  "open a macro for its entry points.": "برای دیدن نقاط ورود، یک ماکرو را باز کنید.",
  "these four judge the last full day against its usual level, so they change once a day": "این چهار کارت آخرین روزِ کامل را با سطح معمولش می‌سنجند و روزی یک بار عوض می‌شوند",
  "when does conversion actually happen?": "نرخ تبدیل واقعاً چه ساعتی اتفاق می‌افتد؟",
  "end to end cr": "CR سرتاسری",
  "no clear difference ": "تفاوت روشنی ندارد",

  /* ── مرکز کنترل: CPO ───────────────────────────── */
  "health": "سلامت",
  "funnel": "قیف",
  "entry points": "نقاط ورود",
  "product surfaces": "سطوح محصول",
  "geography": "جغرافیا",
  "signals": "سیگنال‌ها",
  "signals (": "سیگنال‌ها (",
  ") ranked by impact": ") به ترتیب اثر",
  "what": "چه شده",
  "action": "اقدام",
  "suggested owner:": "مالک پیشنهادی:",
  "product manager": "مدیر محصول",
  "regional lead": "مسئول منطقه",
  "marketing lead": "مسئول مارکتینگ",
  "growth lead": "مسئول رشد",
  "explain": "توضیح بده",
  "open the data": "دیدن داده",
  "why? journey rca": "چرا؟ RCA مسیرها",
  "open alerts and actions": "هشدارها و اقدام‌های باز",
  "open": "باز",
  "entry journeys": "مسیرهای ورود",
  "high": "زیاد",
  "medium": "متوسط",
  "low": "کم",
  "· owner:": "· مالک:",
  "owner:": "مالک:",
  "unassigned": "بدون مالک",
  "lost": "از دست رفته",

  /* ── مرکز کنترل: CRO ───────────────────────────── */
  "close-cart cr": "CR (Close Cart)",
  "what explains the change": "چه چیزی تغییر را توضیح می‌دهد",
  "the change in the session-to-order rate, split by platform into a rate effect and a mix effect. the parts add up exactly.": "تغییر نرخ سشن به سفارش، به تفکیک پلتفرم و در دو بخش «اثر نرخ» و «اثر ترکیب». جمع بخش‌ها دقیقاً برابر کل است.",
  "usual": "معمول",
  "yesterday": "دیروز",
  "rate effect": "اثر نرخ",
  "pt · mix effect": "pt · اثر ترکیب",
  "mix effect": "اثر ترکیب",
  "others": "سایر",
  "rate effect: converts differently": "اثر نرخ: تبدیل متفاوت",
  "mix effect: traffic moved": "اثر ترکیب: جابه‌جایی ترافیک",
  "basis:": "مبنا:",
  "close-cart sessions / all sessions": "سشن‌های Close Cart / همه‌ی سشن‌ها",
  "days": "روز",
  "platform x entry point": "پلتفرم × نقطه‌ی ورود",
  "where the order rate is strong or slipping, by channel and entry page.": "نرخ سفارش کجا قوی است و کجا در حال لغزش، به تفکیک کانال و صفحه‌ی ورود.",
  "cities against their own usual order rate.": "شهرها در برابر نرخ سفارش معمول خودشان.",
  "to": "تا",
  "headline": "تیتر",

  /* ── قیف کلی ───────────────────────────── */
  "from visit to order: key metrics, drop-offs and changes vs the comparison period.": "از بازدید تا سفارش: شاخص‌های کلیدی، ریزش‌ها و تغییرات نسبت به دوره‌ی مقایسه.",
  "standard": "استاندارد",
  "valid-click": "کلیک معتبر",
  "all": "همه",
  "more": "بیشتر",
  "more options": "گزینه‌های بیشتر",
  "methodology": "روش‌شناسی",
  "range": "بازه",
  "day": "روز",
  "today": "امروز",
  "overall cr (close cart)": "CR کلی (Close Cart)",
  "vs previous period": "نسبت به دوره‌ی قبل",
  "total sessions": "کل سشن‌ها",
  "gross orders": "سفارش ناخالص",
  "net orders": "سفارش خالص",
  "overall conversion funnel": "قیف تبدیل کلی",
  "hover or click a stage for detail. the soft shape behind is the comparison period.": "برای جزئیات، نشانگر را روی یک مرحله ببرید یا کلیک کنید. شکل کم‌رنگ پشت، دوره‌ی مقایسه است.",
  "all sessions": "همه‌ی سشن‌ها",
  "1st valid click": "اولین کلیک معتبر",
  "1st click": "اولین کلیک",
  "add to cart": "افزودن به سبد",
  "go to basket": "رفتن به سبد",
  "continue purchase": "ادامه‌ی خرید",
  "close cart": "Close Cart",
  "gross order": "سفارش ناخالص",
  "drop-off": "ریزش",
  "gain": "رشد",
  "funnel health": "سلامت قیف",
  "better than the comparison period": "بهتر از دوره‌ی مقایسه",
  "worse than the comparison period": "بدتر از دوره‌ی مقایسه",
  "main issue:": "مشکل اصلی:",
  "conversion trend": "روند نرخ تبدیل",
  "actual": "واقعی",
  "comparison period": "دوره‌ی مقایسه",
  "funnel: sessions by stage": "قیف: سشن در هر مرحله",
  "of": "از",
  "valid session rate": "نرخ سشن معتبر",
  "overall cr (gross)": "CR کلی (ناخالص)",
  "gross → net order cr": "CR ناخالص به خالص",
  "behavioral alerts": "هشدارهای رفتاری",
  "days that deviated from the rolling baseline (z-score on daily overall cr).": "روزهایی که از خط پایه‌ی متحرک فاصله گرفتند (z-score روی CR کلی روزانه).",
  "guardrails": "حفاظ‌ها",
  "overall cr (on total)": "CR کلی (روی کل)",
  "pipeline traffic": "ترافیک قیف",
  "total reach": "دسترسی کل",
  "gross volume": "حجم ناخالص",
  "daily digest": "خلاصه‌ی روزانه",
  "hand-off trends": "روند انتقال بین مرحله‌ها",
  "daily table": "جدول روزانه",
  "generated": "ساخته‌شده",
  "· view:": "· نما:",
  ". formulas for every figure above are in the": ". فرمول همه‌ی عددهای بالا در تب",
  "tab.": "آمده است.",
  "latest": "آخرین",
  "· baseline": "· خط پایه",
  "local data": "داده‌ی محلی",
  "valid sessions ÷ total sessions.": "سشن معتبر ÷ کل سشن‌ها.",
  "all distinct sessions on the platform.": "همه‌ی سشن‌های یکتای پلتفرم.",
  "unique users behind the valid sessions in the period.": "کاربران یکتای پشت سشن‌های معتبر در این بازه.",

  /* ── کانال‌های ورود ───────────────────────────── */
  "how users begin a path that can lead to an order.": "کاربران چطور مسیری را شروع می‌کنند که می‌تواند به سفارش برسد.",
  "◀ share of sessions": "◀ سهم سشن‌ها",
  "share of orders ▶": "سهم سفارش‌ها ▶",
  "share of sessions": "سهم سشن‌ها",
  "share of orders": "سهم سفارش‌ها",
  "users exploring vendor or product categories.": "کاربرانی که دسته‌بندی فروشنده یا محصول را می‌گردند.",
  "users who already know what they want.": "کاربرانی که می‌دانند چه می‌خواهند.",
  "users entering through promotional discount programs.": "کاربرانی که از برنامه‌های تخفیف وارد می‌شوند.",
  "returning users entering from previous orders.": "کاربران بازگشتی که از سفارش‌های قبلی وارد می‌شوند.",
  "users entering through product or service surfaces.": "کاربرانی که از سطوح محصول یا سرویس وارد می‌شوند.",
  "users entering through sponsored vendor placements.": "کاربرانی که از جایگاه‌های اسپانسری فروشنده‌ها وارد می‌شوند.",
  "session share": "سهم سشن",
  "pt vs usual": "pt نسبت به معمول",
  "macro": "ماکرو",
  "channels and their entry pages": "کانال‌ها و صفحه‌های ورودشان",
  "channel / entry page": "کانال / صفحه‌ی ورود",
  "search page": "صفحه‌ی جست‌وجو",
  "gem page": "صفحه‌ی Gem",
  "party page": "صفحه‌ی پارتی",
  "off-box page": "صفحه‌ی Off-Box",
  "orders page": "صفحه‌ی سفارش‌ها",
  "meal for one page": "صفحه‌ی Meal For One",
  "landing pages": "صفحه‌های لندینگ",
  "entry page bars show its part of the channel's sessions. a conversion in red is under 60% of its channel's.": "نوار هر صفحه‌ی ورود، سهمش از سشن‌های کانال را نشان می‌دهد. نرخ تبدیل قرمز یعنی کمتر از ۶۰٪ نرخ کانال خودش.",
  "share of sessions and orders by entry channel": "سهم سشن و سفارش به تفکیک کانال ورود",

  /* ── قیف‌های کلان ───────────────────────────── */
  "which program or surface produced the buying path, grouped by entry channel.": "کدام برنامه یا سطح، مسیر خرید را ساخت؛ به تفکیک کانال ورود.",
  "conv.": "تبدیل",
  "vendor-based": "فروشنده‌محور",
  "product-based": "محصول‌محور",
  "mixed / hub": "ترکیبی / هاب",
  "visitors": "بازدیدکننده‌ها",
  "opened the page": "صفحه را باز کردند",
  "credited here": "به اینجا نسبت داده شد",
  "checkout": "پرداخت",
  "vdp / vendor menu": "VDP / منوی فروشنده",
  "plp / list": "PLP / لیست",
  "pdp / product page": "PDP / صفحه‌ی محصول",
  "channel / macro / entry point": "کانال / ماکرو / نقطه‌ی ورود",
  "basket": "سبد",
  "order": "سفارش",
  "exits": "خروج‌ها",
  "exit": "خروج",
  "the path": "مسیر",
  "from entry to order. every session is credited once, to its last entry click before the first add to cart.": "از ورود تا سفارش. هر سشن فقط یک بار و به آخرین کلیک ورودِ پیش از اولین افزودن به سبد نسبت داده می‌شود.",
  "channel": "کانال",
  "entry point": "نقطه‌ی ورود",
  "landing types": "نوع لندینگ",
  "offer sheet": "برگه‌ی پیشنهاد",
  "exit is not a drop-off: the user deliberately leaves snappfood for another product (snapp express, snappshop, foodro), and those orders are not in this data.": "خروج ریزش نیست: کاربر عمداً به محصول دیگری (اسنپ اکسپرس، اسنپ‌شاپ، فودرو) می‌رود و آن سفارش‌ها در این داده نیستند.",
  "shortcut": "میان‌بر",
  "search box": "کادر جست‌وجو",
  "supertype tile": "آیکون Supertype",
  "carousel": "کاروسل",
  "in-page": "داخل صفحه",
  "banner": "بنر",
  "quick access": "دسترسی سریع",
  "reorder": "سفارش دوباره",
  "open baskets": "سبدهای باز",
  "continue basket": "ادامه‌ی سبد",
  "bottom bar": "نوار پایین",

  /* ── پارتی / Best Value / Meal For One ───────────────────────────── */
  "party funnel": "قیف پارتی",
  "the party carousel, home and non-home, plus the super app funnel": "کاروسل پارتی در خانه و بیرون از خانه، به‌علاوه‌ی قیف سوپراپ",
  "home carousel": "کاروسل خانه",
  "non-home carousel": "کاروسل غیرخانه",
  "super app": "سوپراپ",
  "history is still being pulled from trino": "تاریخچه هنوز از Trino در حال دریافت است",
  "days since": "روز از",
  "numbers on this page cover the days stored so far": "عددهای این صفحه فقط روزهای ذخیره‌شده تا الان را پوشش می‌دهند",
  "and fill in by themselves.": "و خودشان کامل می‌شوند.",
  "7 days": "۷ روز",
  "14 days": "۱۴ روز",
  "30 days": "۳۰ روز",
  "all cities": "همه‌ی شهرها",
  "city unknown": "شهر نامشخص",
  "party carousel - home funnel": "کاروسل پارتی، قیف خانه",
  "sessions at each step, from impression to close-cart": "سشن در هر مرحله، از Impression تا Close Cart",
  "click a stage for its details": "برای جزئیات روی یک مرحله کلیک کنید",
  "impression sessions": "سشن‌های Impression",
  "close-cart sessions": "سشن‌های Close Cart",
  "overall cr": "CR کلی",
  "biggest drop": "بیشترین افت",
  "trend by day": "روند روزانه",
  "volume of the main steps, or the close-cart conversion of impressions. today is left out until the day is over.": "حجم مرحله‌های اصلی یا نرخ Close Cart نسبت به Impression. امروز تا پایان روز حساب نمی‌شود.",
  "volume": "حجم",
  "carousel title": "عنوان کاروسل",
  "city": "شهر",
  "impressions": "Impression",
  "clicks": "کلیک",
  "added": "افزوده‌شده",
  "pick a day": "انتخاب روز",
  "metric": "شاخص",
  "date": "تاریخ",
  "meal for one funnel": "قیف Meal For One",
  "executive conversion overview: the 10-second health check": "نمای مدیریتی تبدیل: چک‌آپ ۱۰ ثانیه‌ای",
  "end-to-end conversion rate": "نرخ تبدیل سرتاسری",
  "when did conversion change?": "نرخ تبدیل کی تغییر کرد؟",
  "daily": "روزانه",
  "weekly": "هفتگی",
  "monthly": "ماهانه",
  "impression / session volume": "حجم Impression / سشن",
  "is traffic growing or shrinking?": "ترافیک در حال رشد است یا کاهش؟",
  "top opportunities": "بهترین فرصت‌ها",
  "where is the highest actionable upside?": "بیشترین رشدِ قابل‌اقدام کجاست؟",
  "area": "منطقه",
  "conversion funnel": "قیف تبدیل",
  "where are users leaking?": "کاربران کجا از دست می‌روند؟",
  "biggest leak flagged": "بزرگ‌ترین نشتی علامت خورد",
  "drop": "افت",
  "· biggest leak": "· بزرگ‌ترین نشتی",
  "of total loss)": "از کل ریزش)",
  "first click sessions": "سشن‌های اولین کلیک",
  "add to cart sessions": "سشن‌های افزودن به سبد",
  "go to basket sessions": "سشن‌های رفتن به سبد",
  "basket page sessions": "سشن‌های صفحه‌ی سبد",
  "close cart sessions": "سشن‌های Close Cart",
  "sessions lost between the top and bottom of the funnel.": "سشن بین بالا و پایین قیف از دست رفت.",
  "key insights": "بینش‌های کلیدی",
  "what deserves attention?": "چه چیزی ارزش توجه دارد؟",
  "closing the gap to benchmark is a meaningful uplift": "بستن فاصله تا معیار، رشد معناداری می‌سازد",
  "anomaly": "ناهنجاری",
  "period average": "میانگین دوره",
  "first-click rate": "نرخ اولین کلیک",
  "purchase intensity": "شدت خرید",
  "opportunity": "فرصت",
  "traffic": "ترافیک",
  "current cr": "CR فعلی",
  "benchmark": "معیار",
  "est. upside": "رشد تخمینی",
  "best value": "Best Value",
  "the best value carousel, from impression to order": "کاروسل Best Value، از Impression تا سفارش",
  "entry paths": "مسیرهای ورود",
  "trends": "روندها",
  "daily data": "داده‌ی روزانه",
  "carousel impressions (sessions)": "Impression کاروسل (سشن)",
  "entered (any path)": "ورود (هر مسیری)",
  "best value funnel": "قیف Best Value",
  "sessions at each step. right columns: share of the previous step and of the first step.": "سشن در هر مرحله. ستون‌های کناری: سهم از مرحله‌ی قبل و از مرحله‌ی اول.",
  "carousel impression": "Impression کاروسل",
  "product selected (p0)": "انتخاب محصول (P0)",
  "added to cart": "افزوده به سبد",
  "kept in cart": "ماندن در سبد",
  "went to basket": "رفتن به سبد",
  "basket page": "صفحه‌ی سبد",
  "of previous step": "از مرحله‌ی قبل",
  "of the first step": "از مرحله‌ی اول",

  /* ── کاوشگر قیف / هیت‌مپ / اثر افزایشی ───────────────────────────── */
  "channel, macro and entry point, down to landing, basket, checkout and order.": "کانال، ماکرو و نقطه‌ی ورود؛ تا لندینگ، سبد، پرداخت و سفارش.",
  "channel, macro and entry point": "کانال، ماکرو و نقطه‌ی ورود",
  "entry page funnel by day and city": "قیف صفحه‌ی ورود به تفکیک روز و شهر",
  "basket, checkout and order steps for each entry page, with date range and city filters.": "مرحله‌های سبد، پرداخت و سفارش برای هر صفحه‌ی ورود، با فیلتر تاریخ و شهر.",
  "home heatmap · ": "هیت‌مپ خانه · ",
  "what a launch added to the platform, what it took from other services, and how sure we are": "یک لانچ چه به پلتفرم اضافه کرد، از سرویس‌های دیگر چه گرفت و چقدر مطمئنیم",
  "cannibalization & incrementality": "هم‌خواری و اثر افزایشی",

  /* ── RCA ───────────────────────────── */
  "daily · yesterday by default": "روزانه · پیش‌فرض دیروز",
  "baseline": "خط پایه",
  "8-week median": "میانه‌ی ۸ هفته",
  "same weekday, last week": "همان روز هفته، هفته‌ی قبل",
  "same weekday, 4 weeks ago": "همان روز هفته، ۴ هفته قبل",
  "same weekday, last 4 weeks": "همان روز هفته، ۴ هفته‌ی اخیر",
  "time zone": "منطقه‌ی زمانی",
  "refresh": "به‌روزرسانی",
  "newest complete day:": "آخرین روز کامل:",
  "copy snapshot (markdown)": "کپی خلاصه (Markdown)",
  "day to analyse": "روزِ تحلیل",
  "change": "تغییر",
  "counterfactual order gap": "شکاف سفارش در سناریوی خلاف واقع",
  "estimate, needs a baseline": "تخمین؛ به خط پایه نیاز دارد",
  "check warnings": "بررسی هشدارها",
  "steps counted unordered": "مرحله‌ها بدون ترتیب شمرده شدند",
  "significant drop": "افت معنادار",
  "significant rise": "رشد معنادار",
  "within normal": "در محدوده‌ی معمول",
  "relative": "نسبی",
  "cohort": "کوهورت",
  "· inspect data": "· بررسی داده",
  "order placed (close cart)": "ثبت سفارش (Close Cart)",
  "order placed": "ثبت سفارش",
  "what moved": "چه چیزی جابه‌جا شد",
  "funnel completion (close-cart sessions ÷ valid sessions)": "تکمیل قیف (سشن‌های Close Cart ÷ سشن‌های معتبر)",
  "residual": "باقی‌مانده",
  "traffic quality by": "کیفیت ترافیک بر اساس",
  "extra traffic converts": "ترافیک اضافه تبدیل می‌شود",
  "the extra sessions convert like usual: the drop is not a traffic-quality effect.": "سشن‌های اضافه مثل همیشه تبدیل می‌شوند: افت از کیفیت ترافیک نیست.",
  "extra sessions": "سشن‌های اضافه",
  "share of extra": "سهم اضافه",
  "extra converts at": "نرخ تبدیل اضافه",
  "usual rate": "نرخ معمول",
  "unknown city (no city_id)": "شهر نامشخص (بدون city_id)",
  "by": "بر اساس",
  "platform": "پلتفرم",
  "close-cart sessions ÷ sessions": "سشن‌های Close Cart ÷ سشن‌ها",
  "converted differently.": "متفاوت تبدیل شدند.",
  "rate": "نرخ",
  "share": "سهم",
  "daily · click-level entry points": "روزانه · نقاط ورود در سطح کلیک",
  "all platforms": "همه‌ی پلتفرم‌ها",
  "entry sessions": "سشن‌های ورود",
  "order sessions": "سشن‌های سفارش",
  "journeys converted differently": "مسیرها متفاوت تبدیل شدند",
  "traffic moved between journeys": "ترافیک بین مسیرها جابه‌جا شد",
  "drivers, the most orders first": "عامل‌ها، به ترتیب اثر روی سفارش",
  "platform × journey": "پلتفرم × مسیر",
  "+ create action": "+ ساخت اقدام",
  "changes logged in the week up to this day": "تغییرات ثبت‌شده در هفته‌ی منتهی به این روز",
  "change log →": "تاریخچه‌ی تغییرات ←",
  "none. log releases, rollouts and campaigns in the change log so a drop can be read against what shipped.": "هیچ. ریلیزها، رول‌اوت‌ها و کمپین‌ها را در تاریخچه‌ی تغییرات ثبت کنید تا هر افت کنار چیزی که منتشر شد خوانده شود.",
  "which step moved the day": "کدام مرحله روز را جابه‌جا کرد",
  "which journey moved the day": "کدام مسیر روز را جابه‌جا کرد",
  "rate effect of each journey in orders. the traffic mix part is in the table below.": "اثر نرخ هر مسیر بر حسب سفارش. سهم ترکیب ترافیک در جدول پایین است.",
  "orders page (retention)": "صفحه‌ی سفارش‌ها (بازگشتی)",
  "no entry click": "بدون کلیک ورود",
  "eco (best value)": "Eco (Best Value)",
  "journey": "مسیر",
  "share / baseline": "سهم / خط پایه",
  "conversion / baseline": "تبدیل / خط پایه",
  "weakest step": "ضعیف‌ترین مرحله",
  "status": "وضعیت",
  "normal": "عادی",
  "rise": "رشد",
  "entry points that moved most": "نقاط ورودی که بیشترین تغییر را داشتند",
  "single entry points with at least 1,000 sessions on the day and on the baseline, the most orders first.": "نقاط ورود تکی با دست‌کم ۱٬۰۰۰ سشن در روز و در خط پایه، به ترتیب اثر روی سفارش.",
  "vendor card in a vendor list": "کارت فروشنده در لیست فروشنده‌ها",
  "vendor result in search": "نتیجه‌ی فروشنده در جست‌وجو",
  "product card on off box": "کارت محصول در Off-Box",
  "product result in search": "نتیجه‌ی محصول در جست‌وجو",
  "orders tab, from a vendor list": "تب سفارش‌ها، از لیست فروشنده‌ها",
  "vendor card on home": "کارت فروشنده در خانه",
  "vendor card on off box": "کارت فروشنده در Off-Box",
  "deal offer card on home": "کارت پیشنهاد ویژه در خانه",
  "continue an open basket": "ادامه‌ی یک سبد باز",
  "active order card": "کارت سفارش فعال",
  "bottom nav bar on off box": "نوار پایین در Off-Box",
  "product card on landing": "کارت محصول در لندینگ",
  "method": "روش",
  "source:": "منبع:",
  "conversion:": "نرخ تبدیل:",
  "order sessions / entry sessions.": "سشن‌های سفارش / سشن‌های ورود.",
  "steps:": "مرحله‌ها:",
  "entry → add to cart → basket → checkout → order": "ورود ← افزودن به سبد ← سبد ← پرداخت ← سفارش",
  "baseline:": "خط پایه:",
  "significance:": "معناداری:",
  "a driver is a hypothesis to check (a release, an outage, a logging change), not a proven cause.": "یک عامل، فرضیه‌ای برای بررسی است (یک ریلیز، یک قطعی، تغییر لاگ)، نه علت اثبات‌شده.",
  "step split: the conversion is the product of the four step rates, so its change splits exactly over them (shapley values).": "تفکیک مرحله‌ها: نرخ تبدیل حاصل‌ضرب چهار نرخ مرحله است، پس تغییرش دقیقاً بین آن‌ها تقسیم می‌شود (مقادیر Shapley).",
  "steps are counted per session that day, not strictly in order: a reorder can open the basket without an add to cart, so a step rate can pass 100 %.": "مرحله‌ها برای هر سشن در همان روز شمرده می‌شوند، نه لزوماً به ترتیب: سفارش دوباره می‌تواند بدون افزودن به سبد، سبد را باز کند؛ پس نرخ یک مرحله ممکن است از ۱۰۰٪ بگذرد.",
  "stage": "مرحله",
  "valid session": "سشن معتبر",
  "not measured": "اندازه‌گیری نشده",
  "reached / eligible": "رسیده / واجد شرایط",
  "stage cr": "CR مرحله",
  "contribution": "سهم در تغییر",
  "data quality": "کیفیت داده",
  "freshness": "تازگی داده",
  "orders / sessions": "سفارش / سشن",
  "baseline cr": "CR خط پایه",
  "findings": "یافته‌ها",
  "risks": "ریسک‌ها",
  "open questions for you": "سؤال‌های باز برای شما",
  "architecture map": "نقشه‌ی معماری",
  "piece": "بخش",
  "role": "نقش",

  /* ── ساعتی ───────────────────────────── */
  "hourly & shift performance": "عملکرد ساعتی و شیفت‌ها",
  "overview(hourly)": "نمای کلی (ساعتی)",
  "impression sessions (session-hours)": "سشن‌های Impression (سشن-ساعت)",
  "end-to-end cr": "CR سرتاسری",
  "e2e cr": "E2E CR",
  "close cart (session-hours)": "Close Cart (سشن-ساعت)",
  "shift performance": "عملکرد شیفت‌ها",
  "which day-part converts best, and where is the biggest missed volume?": "کدام بخش روز بهتر تبدیل می‌کند و بیشترین حجم ازدست‌رفته کجاست؟",
  "overnight": "شبانه",
  "share of day": "سهم از روز",
  "morning": "صبح",
  "weakest": "ضعیف‌ترین",
  "lunch": "ناهار",
  "best": "بهترین",
  "dinner": "شام",
  "conversion by hour of day": "نرخ تبدیل به تفکیک ساعت",
  "peak": "اوج",
  "hour-by-hour": "ساعت به ساعت",
  "every hour, sorted by clock.": "همه‌ی ساعت‌ها، به ترتیب ساعت.",
  "hour": "ساعت",
  "counts are session-hours (a session active across two hours is counted in both). every rate divides matching numerator/denominator within the same bucket, so rates are unaffected.": "شمارش‌ها سشن-ساعت هستند (سشنی که در دو ساعت فعال بوده در هر دو شمرده می‌شود). هر نرخ صورت و مخرج همان بازه را تقسیم می‌کند، پس نرخ‌ها تحت‌تأثیر نیستند.",

  /* ── شهرها / مناطق / پلتفرم‌ها ───────────────────────────── */
  "city performance": "عملکرد شهرها",
  "provinces by traffic": "استان‌ها بر اساس ترافیک",
  "of traffic": "از ترافیک",
  "· refreshes every minute": "· هر دقیقه به‌روز می‌شود",
  "cities at a glance": "شهرها در یک نگاه",
  "ranked segments": "بخش‌های رتبه‌بندی‌شده",
  "which cities need attention?": "کدام شهرها توجه می‌خواهند؟",
  "highest opportunity": "بیشترین فرصت",
  "most traffic": "بیشترین ترافیک",
  "highest cr": "بالاترین CR",
  "biggest cr change": "بیشترین تغییر CR",
  "benchmark:": "معیار:",
  "traffic-weighted network cr": "CR شبکه، وزن‌دهی‌شده با ترافیک",
  "). status is comparative, not a fixed threshold.": "). وضعیت نسبی است، نه آستانه‌ی ثابت.",
  "traffic share": "سهم ترافیک",
  "vs benchmark": "نسبت به معیار",
  "δ cr": "Δ CR",
  "needs action": "نیازمند اقدام",
  "unattributed": "نامشخص",
  "zoom in": "بزرگ‌نمایی",
  "zoom out": "کوچک‌نمایی",
  "reset zoom": "بازنشانی بزرگ‌نمایی",
  "marketing area performance": "عملکرد مناطق مارکتینگ",
  "where is the highest opportunity? ranked by conversion gap × traffic share by default.": "بیشترین فرصت کجاست؟ به‌طور پیش‌فرض بر اساس شکاف نرخ تبدیل × سهم ترافیک.",
  "where is the highest opportunity?": "بیشترین فرصت کجاست؟",
  "how users entered snappfood: web app, native apps, super app and campaigns": "کاربران چطور وارد اسنپ‌فود شدند: وب‌اپ، اپ‌های بومی، سوپراپ و کمپین‌ها",
  "by platform": "به تفکیک پلتفرم",
  "sessions (all platforms)": "سشن (همه‌ی پلتفرم‌ها)",
  "biggest platform": "بزرگ‌ترین پلتفرم",
  "best order rate": "بهترین نرخ سفارش",
  "every platform value": "همه‌ی مقادیر پلتفرم",
  "cr rank": "رتبه‌ی CR",
  "users (user-days)": "کاربران (کاربر-روز)",
  "order rate": "نرخ سفارش",
  "came from the super app page": "از صفحه‌ی سوپراپ آمده",
  "web app, used on ios": "وب‌اپ، روی iOS",
  "native android app": "اپ اندروید",
  "came from the irancell page (campaign)": "از صفحه‌ی ایرانسل آمده (کمپین)",
  "native ios app (iphone)": "اپ iOS (آیفون)",

  /* ── هشدارها / رخداد / اقدام / تغییرات ───────────────────────────── */
  "a metric that leaves its own recent range raises an alert here, and closes it when it comes back.": "هر شاخصی که از بازه‌ی اخیرِ خودش بیرون بزند، اینجا هشدار می‌سازد و وقتی برگردد، هشدار بسته می‌شود.",
  "check now": "همین حالا بررسی کن",
  "open, nobody has picked these up yet": "باز؛ هنوز کسی برشان نداشته",
  "in progress": "در حال رسیدگی",
  "no alert is being worked on": "روی هیچ هشداری کار نمی‌شود",
  "resolved, last 7 days": "حل‌شده، ۷ روز اخیر",
  "any severity": "هر شدتی",
  "detected": "شناسایی شد",
  "· data for": "· داده‌ی",
  "10-day average": "میانگین ۱۰ روزه",
  "improvement": "بهبود",
  "overall platform funnel": "قیف کلی پلتفرم",
  "only finished days are judged: today, and a day whose data has not fully arrived, are skipped. an alert is a statistical deviation that says where to look. it is not a confirmed cause.": "فقط روزهای تمام‌شده بررسی می‌شوند: امروز و روزی که داده‌اش کامل نرسیده کنار گذاشته می‌شوند. هشدار یک انحراف آماری است که می‌گوید کجا را نگاه کنیم؛ علت قطعی نیست.",
  "end-to-end conversion rate ": "نرخ تبدیل سرتاسری ",
  "no incident": "رخدادی نیست",
  "synthetic connected": "Synthetic وصل است",
  "whole day": "کل روز",
  "manual entry": "ثبت دستی",
  "incidents from synthetic monitoring, and drops in orders or sessions found in the data, appear here on their own. add one by hand with manual entry.": "رخدادهای پایش Synthetic و افت سفارش یا سشن که در داده پیدا می‌شود، خودکار اینجا می‌آیند. برای ثبت دستی از «ثبت دستی» استفاده کنید.",
  "30 minutes": "۳۰ دقیقه",
  "resolved": "حل‌شده",
  "found in data": "پیداشده در داده",
  "who does what about a finding, by when, and whether conversion moved after it": "چه کسی، تا کی، برای یک یافته چه می‌کند و آیا نرخ تبدیل بعدش تکان خورد",
  "done": "انجام‌شده",
  "cancelled": "لغوشده",
  "overdue": "عقب‌افتاده",
  "open and in progress": "باز و در حال انجام",
  "+ new action": "+ اقدام جدید",
  "no actions here. create one from a journey rca driver, an alert, or with new action.": "اقدامی اینجا نیست. از یک عامل در RCA مسیرها، یک هشدار یا دکمه‌ی «اقدام جدید» بسازید.",
  "releases, rollouts and campaigns, and what conversion did after each": "ریلیزها، رول‌اوت‌ها و کمپین‌ها و اینکه نرخ تبدیل بعد از هرکدام چه کرد",
  "each change is measured on its platform and journey: conversion in the 7 days before it against the 7 days from it. journey rca names it beside any drop in the week after.": "هر تغییر روی پلتفرم و مسیر خودش سنجیده می‌شود: نرخ تبدیل ۷ روز قبل در برابر ۷ روز بعد. RCA مسیرها آن را کنار هر افتِ هفته‌ی بعد نام می‌برد.",
  "+ log a change": "+ ثبت تغییر",
  "no changes logged yet. log releases, rollouts and campaigns here, so a drop can be read against what shipped.": "هنوز تغییری ثبت نشده. ریلیزها، رول‌اوت‌ها و کمپین‌ها را اینجا ثبت کنید تا هر افت کنار چیزی که منتشر شد خوانده شود.",
  "behavioral shock monitor": "پایش شوک رفتاری",
  "security": "امنیتی",
  "unreviewed": "بررسی‌نشده",
  "no data yet": "هنوز داده‌ای نیست",
  "human": "انسانی",
  "social unrest": "ناآرامی اجتماعی",
  "economic": "اقتصادی",
  "infrastructure": "زیرساخت",
  "couldn’t load this view": "این نما بارگذاری نشد",
  "couldn't load this event's impact.": "اثر این رویداد بارگذاری نشد.",

  /* ── مدیریت ───────────────────────────── */
  "admin panel": "پنل مدیریت",
  "users, rbac grant matrix, funnel registry, ownership, alert rules, notifications, audit log": "کاربران، ماتریس دسترسی RBAC، رجیستری قیف، مالکیت، قوانین هشدار، اعلان‌ها و لاگ ممیزی",
  "retry": "تلاش دوباره",
  "trino ingestion": "ورود داده از Trino",
  "catching up": "در حال جبران",
  "updated": "به‌روزشده",
  "just now": "همین الان",
  "stop": "توقف",
  "catch-up running...": "جبران در حال اجرا…",
  "today's numbers": "عددهای امروز",
  "every 15 min": "هر ۱۵ دقیقه",
  "control center, at any hour": "مرکز کنترل، هر ساعتی",
  "heavy queries": "کوئری‌های سنگین",
  "any hour": "هر ساعتی",
  "no hour limit": "بدون محدودیت ساعت",
  "past days missing": "روزهای گذشته‌ی ناقص",
  "one every 3 h, or catch up now": "هر ۳ ساعت یکی، یا همین حالا جبران کن",
  "update the sheet now": "همین حالا شیت را به‌روز کن",
  "last written to the sheet": "آخرین نوشتن در شیت",
  "last check": "آخرین بررسی",
  "none yet": "هنوز هیچ",
  "runs within 30 min": "ظرف ۳۰ دقیقه اجرا می‌شود",
  "stopped days": "روزهای متوقف‌شده",
  "dataset...": "دیتاست…",
  "dataset": "دیتاست",
  "from": "از",
  "to (optional)": "تا (اختیاری)",
  "stopped": "متوقف",
  "start": "شروع",
  "start again": "شروع دوباره",
  "came back empty": "خالی برگشت",
  "now": "اکنون",
  "imported history": "تاریخچه‌ی واردشده",
  "from trino": "از Trino",
  "missing": "ناقص",
  "today (partial)": "امروز (ناقص)",
  "latest stored day:": "آخرین روز ذخیره‌شده:",
  "recent runs": "اجراهای اخیر",
  "newest first. each row is one trino query for one day.": "جدیدترین اول. هر ردیف یک کوئری Trino برای یک روز است.",
  "when": "زمان",
  "time": "زمان",
  "detail": "جزئیات",
  "empty": "خالی",
  "stop this day": "توقف این روز",
  "ok": "موفق",
  "last 200 audit entries": "۲۰۰ ثبت آخر ممیزی",
  "every sensitive action: logins, grant changes, ownership changes, rule changes, detection runs. never passwords or tokens.": "همه‌ی کارهای حساس: ورودها، تغییر دسترسی، تغییر مالکیت، تغییر قوانین، اجرای تشخیص. هرگز رمز یا توکن ثبت نمی‌شود.",
  "actor": "انجام‌دهنده",
  "target": "هدف",


  /* ── تکمیلی v2 ───────────────────────────── */
  "valid": "سشن معتبر",
  "home click": "کلیک خانه",
  "the top": "بالای قیف",
  "bottom of the funnel": "پایین قیف",
  "the bottom of the funnel": "پایین قیف",
  "the bottom of the funnel.": "پایین قیف",
  "net orders.": "سفارش خالص",
  "percent under each count is the share of the first stage; chips are the change of that share vs the comparison period.": "درصد زیر هر عدد، سهم آن از مرحله‌ی اول است؛ برچسب‌ها تغییر همین سهم نسبت به دوره‌ی مقایسه‌اند.",
  "percent under each count is the share of the first stage": "درصد زیر هر عدد، سهم آن از مرحله‌ی اول است",
  "id, not actionable ·": "شناسه، قابل اقدام نیست ·",
  "which funnel stages and segments explain a drop in orders / sessions": "کدام مرحله‌ها و بخش‌های قیف، افت سفارش به سشن را توضیح می‌دهند",
  "method, data audit and open questions (gate a)": "روش، ممیزی داده و سؤال‌های باز (Gate A)",
  "gate": "مرحله‌ی تأیید",
  "audit": "ممیزی",
  "(now)": "(الان)",
  "read-only mvp": "MVP فقط‌خواندنی",
  "automation": "خودکارسازی",
  "nothing below is a measured number. gate b needs your approval and the answers to the open questions.": "هیچ‌کدام از عددهای پایین اندازه‌گیری‌شده نیستند. Gate B به تأیید شما و پاسخ سؤال‌های باز نیاز دارد.",
  "wireframe · top controls and summary": "وایرفریم · کنترل‌های بالا و خلاصه",
  "date / time range": "بازه‌ی تاریخ / زمان",
  "time zone: asia/tehran": "منطقه‌ی زمانی: Asia/Tehran",
  "segment: platform · city": "بخش: پلتفرم · شهر",
  "counterfactual order gap (estimate)": "شکاف سفارش در سناریوی خلاف واقع (تخمین)",
  "the session's first menu view, page view or close cart falls in the window.": "اولین دیدن منو، دیدن صفحه یا Close Cart سشن در این بازه است.",
  "δ relative": "Δ نسبی",
  "δ pp": "Δ pp",
  "sample / ci": "نمونه / بازه‌ی اطمینان",
  "time series + baseline overlay (gate b)": "سری زمانی + خط پایه (Gate B)",
  "explainability · inspect data · diagnostic snapshot": "توضیح‌پذیری · بررسی داده · خلاصه‌ی تشخیصی",
  "formula:": "فرمول:",
  ", ordered within the session, each session once.": "، به ترتیب درون سشن، هر سشن یک بار.",
  "windows: same tehran weekday and clock window, d−7 / d−28 / median of 8 weeks.": "بازه‌ها: همان روز هفته و همان ساعت به وقت تهران، D−7 / D−28 / میانه‌ی ۸ هفته.",
  "segment breakdown, hypotheses and the copyable markdown/json snapshot arrive in gate b–c.": "تفکیک بخش‌ها، فرضیه‌ها و خلاصه‌ی قابل‌کپی Markdown/JSON در Gate B–C می‌آیند.",
  "the session clicked a vendor, product, deal offer or reorder after becoming valid.": "سشن پس از معتبر شدن روی فروشنده، محصول، پیشنهاد ویژه یا سفارش دوباره کلیک کرد.",
  "sessions reaching click": "سشن‌هایی که به کلیک رسیدند",
  "the session added an item (or a deal offer) after its first click.": "سشن پس از اولین کلیک، کالا (یا پیشنهاد ویژه‌ای) به سبد اضافه کرد.",
  "sessions reaching add to cart": "سشن‌هایی که به افزودن به سبد رسیدند",
  "the session opened the basket after adding to cart.": "سشن پس از افزودن به سبد، سبد را باز کرد.",
  "sessions reaching basket": "سشن‌هایی که به سبد رسیدند",
  "the session continued to checkout from the basket.": "سشن از سبد به پرداخت رفت.",
  "sessions reaching continue purchase": "سشن‌هایی که به ادامه‌ی خرید رسیدند",
  "sessions with an order": "سشن‌های دارای سفارش",
  "below the cards (gate c)": "زیر کارت‌ها (Gate C)",
  "waterfall: shapley stage effects + mix + orders per session + residual (pp)": "آبشاری: اثر مرحله‌ها با Shapley + ترکیب + سفارش به سشن + باقی‌مانده (pp)",
  "segment ranking (min. cohort, multiple-testing corrected)": "رتبه‌بندی بخش‌ها (حداقل کوهورت، با اصلاح آزمون‌های چندگانه)",
  "instrumentation health: coverage, null sessions, uncoded close_cart, lag": "سلامت ابزارگذاری: پوشش، سشن‌های تهی، close_cart بی‌کد، تأخیر",
  "incident timeline and exportable report": "خط زمانی رخداد و گزارش قابل‌خروجی",
  "event source": "منبع رویداد",
  "order mart": "مارت سفارش",
  "ingestion": "ورود داده",
  "store": "ذخیره‌سازی",
  "frontend": "فرانت‌اند",
  "this page (app server).": "همین صفحه (App Server).",
  "daily gross / net orders per service. no session id, so orders cannot be tied to sessions from it.": "سفارش ناخالص و خالص روزانه به تفکیک سرویس. شناسه‌ی سشن ندارد، پس سفارش‌ها از این منبع به سشن وصل نمی‌شوند.",
  "daily mergetree aggregates only. no intraday funnel table exists.": "فقط تجمیع‌های روزانه‌ی MergeTree. جدول قیف درون‌روزی وجود ندارد.",
  "orders per session exist only as close_cart events. some carry no order_code and some fire twice, so orders need de-duplication and a quality warning.": "سفارش به ازای سشن فقط به شکل رویداد close_cart وجود دارد. بعضی order_code ندارند و بعضی دو بار ثبت می‌شوند؛ پس سفارش‌ها حذف تکرار و هشدار کیفیت لازم دارند.",
  "no ingestion-time column is used anywhere, so late events are only visible by re-pulling a day.": "هیچ‌جا ستون زمان ورود داده استفاده نمی‌شود؛ پس رویدادهای دیررس فقط با دریافت دوباره‌ی یک روز دیده می‌شوند.",
  "segments confirmed in the repo: platform and city. app version, traffic source, payment method and new/returning are not referenced yet.": "بخش‌های تأییدشده در ریپو: پلتفرم و شهر. نسخه‌ی اپ، منبع ترافیک، روش پرداخت و کاربر جدید/بازگشتی هنوز استفاده نشده‌اند.",
  "no bot or internal-traffic filter in the funnel sql.": "در SQL قیف، فیلتر بات یا ترافیک داخلی وجود ندارد.",
  "a wrong close_cart de-duplication moves orders/sessions for instrumentation reasons, not user reasons.": "حذف تکرار اشتباه close_cart، نسبت سفارش به سشن را به دلایل ابزارگذاری تکان می‌دهد، نه رفتار کاربر.",
  "conversion timeout after session start?": "مهلت تبدیل پس از شروع سشن چقدر است؟",
  "is there a bot / internal-traffic marker?": "نشانگر بات / ترافیک داخلی داریم؟",
  "exact dates of the wed–fri drop and any release or incident around them.": "تاریخ دقیق افت چهارشنبه تا جمعه و هر ریلیز یا رخدادی در آن حوالی.",
  "is a new ingestion job acceptable, or must the first version be on-demand only?": "یک job جدید ورود داده قابل‌قبول است یا نسخه‌ی اول باید فقط درخواستی باشد؟",
  "which segment fields exist in extra, and are any of them personal data?": "کدام فیلدهای بخش در extra هستند و آیا هیچ‌کدام داده‌ی شخصی است؟",
  "can a session hold several orders? is there an order table with status and order_code?": "یک سشن می‌تواند چند سفارش داشته باشد؟ جدول سفارشی با status و order_code داریم؟",
  "gate a documents": "اسناد Gate A",
  "architecture map, funnel inventory, findings, risks": "نقشه‌ی معماری، فهرست قیف‌ها، یافته‌ها، ریسک‌ها",
  "cohort, ordered stages, measures, baselines, segments": "کوهورت، مرحله‌های مرتب، شاخص‌ها، خط‌های پایه، بخش‌ها",
  "gates a–d": "Gate A تا D",
  "decisions the owner needs to make": "تصمیم‌هایی که مالک باید بگیرد",
  "stage cards · 6 instrumented stages": "کارت مرحله‌ها · ۶ مرحله‌ی ابزارگذاری‌شده",
  "one card per stage, rendered from the stage list (not a fixed number). order and events from backend/app/ingestion/sql/live_daily.sql.": "برای هر مرحله یک کارت، ساخته‌شده از فهرست مرحله‌ها (نه عدد ثابت). ترتیب و رویدادها از backend/app/ingestion/sql/live_daily.sql.",

  /* ── مودال‌های جزئیات ───────────────────────────── */
  "verdict": "جمع‌بندی",
  ") · today": ") · امروز",
  "pt behind.": "pt عقب‌تر.",
  "how this is measured": "این عدد چطور اندازه‌گیری می‌شود",
  "nothing here is outside its usual range.": "هیچ‌چیز اینجا بیرون از بازه‌ی معمولش نیست.",
  "orders · close-cart sessions": "سفارش · سشن‌های Close Cart",
  "of yesterday's full day": "از کل روز دیروز",
  "yesterday, full day": "دیروز، کل روز",
  "yesterday, same time": "دیروز، همین ساعت",
  "last tuesday, same time": "سه‌شنبه‌ی گذشته، همین ساعت",
  "last monday, same time": "دوشنبه‌ی گذشته، همین ساعت",
  "last wednesday, same time": "چهارشنبه‌ی گذشته، همین ساعت",
  "last thursday, same time": "پنجشنبه‌ی گذشته، همین ساعت",
  "last friday, same time": "جمعه‌ی گذشته، همین ساعت",
  "last saturday, same time": "شنبه‌ی گذشته، همین ساعت",
  "last sunday, same time": "یکشنبه‌ی گذشته، همین ساعت",
  "conversion · close-cart / valid sessions": "نرخ تبدیل · Close Cart / سشن معتبر",
  "yesterday's full day": "کل روز دیروز",
  "today is still running, so the fair comparison is the same clock time (the coloured markers). grey = yesterday's whole day, only to show how far into a normal day we are. ▲ / ▼ = today against each reference. hover a marker for its value.": "امروز هنوز تمام نشده، پس مقایسه‌ی منصفانه با همین ساعت است (نشانگرهای رنگی). خاکستری = کل روز دیروز، فقط برای اینکه ببینیم چقدر از یک روز عادی گذشته. ▲ / ▼ = امروز در برابر هر مرجع. برای دیدن مقدار، نشانگر را روی هرکدام ببرید.",
  "platforms · share of sessions and conversion": "پلتفرم‌ها · سهم سشن و نرخ تبدیل",
  "against a usual": "در برابر معمولِ",
  "inside the normal range: everyday swing, not a change.": "داخل بازه‌ی معمول: نوسان روزمره است، نه تغییر.",
  "open overall funnel": "باز کردن قیف کلی",
  "normal range": "بازه‌ی معمول",
  "usual level learned from": "سطح معمول از روی",
  "distance from usual": "فاصله از معمول",
  "expected orders = the usual conversion rate (same weekday, recent days weigh more) times yesterday's valid sessions.": "سفارش مورد انتظار = نرخ تبدیل معمول (همان روز هفته، با وزن بیشتر برای روزهای اخیر) × سشن‌های معتبر دیروز.",
  "conversion yesterday": "نرخ تبدیل دیروز",
  "difference": "اختلاف",
  "close-cart sessions divided by valid sessions.": "سشن‌های Close Cart تقسیم بر سشن‌های معتبر.",
  "expected": "مورد انتظار",
  "gap": "فاصله",
  "orders at risk": "سفارش‌های در خطر",
  "worth": "ارزش",
  "estimate": "تخمین",
  "average order": "میانگین سفارش",
  "revenue is an estimate: one price per order code, plus half of the events that carry no code.": "درآمد تخمینی است: یک قیمت برای هر کد سفارش، به‌علاوه‌ی نیمی از رویدادهایی که کد ندارند.",
  "usual share": "سهم معمول",
  "order share": "سهم سفارش",
  "(tick = usual)": "(خط کوچک = معمول)",
  "why": "چرا",
  "the eco (best value) carousel, from impression to order.": "کاروسل Eco (Best Value)، از Impression تا سفارش.",
  "confidence:": "اطمینان:",
  "a single city moving on its own usually points at local supply, delivery or an area campaign.": "وقتی فقط یک شهر تکان می‌خورد، معمولاً پای عرضه‌ی محلی، ارسال یا کمپین منطقه‌ای در میان است.",
  "orders and conversion, last 30 days": "سفارش و نرخ تبدیل، ۳۰ روز اخیر",
  "orders and revenue by service": "سفارش و درآمد به تفکیک سرویس",
  "share of orders ·": "سهم سفارش ·",
  "share of revenue ·": "سهم درآمد ·",
  "service · basket size": "سرویس · اندازه‌ی سبد",
  "direct menu link": "لینک مستقیم منو",
  "other direct entry": "سایر ورودهای مستقیم",
  "google to a menu": "گوگل به منو",
  "other snapp apps": "سایر اپ‌های اسنپ",
  "home, click with no event": "خانه، کلیک بدون رویداد",
  "back from payment": "بازگشت از پرداخت",
  "basket size against the average basket: 1.0× is average, green bigger, amber smaller.": "اندازه‌ی سبد در برابر میانگین: ۱٫۰× یعنی میانگین، سبز بزرگ‌تر و نارنجی کوچک‌تر.",
  "click a path to see its entry points.": "برای دیدن نقاط ورود، روی یک مسیر کلیک کنید.",
  "each ordering session counted once, on its last entry click before the first add to cart (the event-mapper model); sessions with no entry click are named by where they came from. money: one price per order code plus half of the events with no code.": "هر سشنِ سفارش‌دهنده یک بار و روی آخرین کلیک ورودِ پیش از اولین افزودن به سبد شمرده می‌شود (مدل event-mapper)؛ سشن‌های بدون کلیک ورود با مبدأشان نام‌گذاری می‌شوند. پول: یک قیمت برای هر کد سفارش، به‌علاوه‌ی نیمی از رویدادهای بی‌کد.",
  "each session counted once, credited to its last entry click before the first add to cart; orders = sessions that ordered. sessions with no entry click are left out of the shares. usual = the 28 days before.": "هر سشن یک بار شمرده می‌شود و به آخرین کلیک ورودِ پیش از اولین افزودن به سبد نسبت داده می‌شود؛ سفارش = سشن‌هایی که سفارش دادند. سشن‌های بدون کلیک ورود در سهم‌ها حساب نمی‌شوند. معمول = ۲۸ روز قبل.",
  "share of sessions that ordered, each variation against the control, last 7 days.": "سهم سشن‌هایی که سفارش دادند، هر واریانت در برابر کنترل، ۷ روز اخیر.",
  "a gap counts as at risk only when the drop is at least 2 noise units below usual. inside the normal range it is everyday swing, not a loss.": "فاصله فقط وقتی «در خطر» حساب می‌شود که افت دست‌کم ۲ واحد نوسان زیر معمول باشد. داخل بازه‌ی معمول، نوسان روزمره است نه زیان.",
  "basis": "مبنا",
  "hide": "بستن توضیح",
  "show": "نمایش",
  "show less": "نمایش کمتر",
  "show more": "نمایش بیشتر",
  "slice = share of sessions": "هر برش = سهم از سشن‌ها",
  "size = traffic share · brightness = conversion rate · top": "اندازه = سهم ترافیک · روشنی = نرخ تبدیل · برترین",
  "the same weekday in the last four weeks, averaged (pooled for the tests)": "همان روز هفته در چهار هفته‌ی اخیر، میانگین‌گیری‌شده (تجمیع‌شده برای آزمون‌ها)",
  "all cities ": "همه‌ی شهرها",
  /* ── عمومی ───────────────────────────── */
  "source": "منبع",
  "· source:": "· منبع:",
  "no data": "داده‌ای نیست",
  "close": "بستن",
  "cancel": "انصراف",
  "save": "ذخیره",
  "apply": "اعمال",
  "reset": "بازنشانی",
  "export": "خروجی",
  "download": "دانلود",
  "filters": "فیلترها",
  "week": "هفته",
  "month": "ماه",
  "trend": "روند",
  "total": "مجموع",
  "average": "میانگین",
  "median": "میانه",
  "details": "جزئیات",
  "overview": "نمای کلی",
  "previous": "قبلی",
  "next": "بعدی",
  "yes": "بله",
  "no": "خیر",
  "edit": "ویرایش",
  "delete": "حذف",
  "search…": "جست‌وجو…",
  "search...": "جست‌وجو…",
  "all time": "کل دوره",
  "custom": "سفارشی",
  "monday": "دوشنبه",
  "tuesday": "سه‌شنبه",
  "wednesday": "چهارشنبه",
  "thursday": "پنجشنبه",
  "friday": "جمعه",
  "saturday": "شنبه",
  "sunday": "یکشنبه"
};

/* اجزای برچسب‌های نقطه‌ی ورود («Vendor card · Search») */
window.FF_PARTS = {
  "vendor card": "کارت فروشنده", "product card": "کارت محصول", "search box": "کادر جست‌وجو", "vendor list": "لیست فروشنده‌ها",
  "search vendor list": "لیست فروشنده‌های جست‌وجو", "result tab": "تب نتایج", "see all vendors": "همه‌ی فروشنده‌ها", "filter": "فیلتر",
  "sub-category": "زیردسته", "bottom bar": "نوار پایین", "shortcut": "میان‌بر", "supertype tile": "آیکون Supertype",
  "all supertypes": "همه‌ی Supertypeها", "breadcrumb": "مسیر صفحه", "product list": "لیست محصولات", "category": "دسته‌بندی",
  "home": "خانه", "landing": "لندینگ", "search": "جست‌وجو", "carousel title": "عنوان کاروسل", "see all": "همه", "tab": "تب",
  "gem banner": "بنر Gem", "banner": "بنر", "quick access": "دسترسی سریع", "offer card": "کارت پیشنهاد", "off box": "Off-Box",
  "off-box tab": "تب Off-Box", "orders": "سفارش‌ها", "user profile": "پروفایل", "party": "پارتی", "meal for one": "Meal For One",
  "active order": "سفارش فعال", "favorite vendors list": "فروشنده‌های محبوب", "promotion center": "مرکز تخفیف‌ها",
  "pro vendor card": "کارت فروشنده‌ی Pro", "pro landing": "لندینگ Pro", "gem": "Gem", "eco-landing": "لندینگ Eco",
  "jimbo": "jimbo", "supertype": "Supertype", "off-box": "Off-Box", "eco (best value)": "Eco (Best Value)",
  "orders page (retention)": "صفحه‌ی سفارش‌ها (بازگشتی)", "landing pages": "صفحه‌های لندینگ", "no entry click": "بدون کلیک ورود",
  "sponsored": "اسپانسری", "retention": "بازگشتی"
};

window.FF_DAYS = { saturday: "شنبه", sunday: "یکشنبه", monday: "دوشنبه", tuesday: "سه‌شنبه", wednesday: "چهارشنبه", thursday: "پنجشنبه", friday: "جمعه", sat: "شنبه", sun: "یکشنبه", mon: "دوشنبه", tue: "سه‌شنبه", wed: "چهارشنبه", thu: "پنجشنبه", fri: "جمعه" };
window.FF_MONTHS = { jan: "ژانویه", feb: "فوریه", mar: "مارس", apr: "آوریل", may: "مه", jun: "ژوئن", jul: "ژوئیه", aug: "اوت", sep: "سپتامبر", oct: "اکتبر", nov: "نوامبر", dec: "دسامبر" };

/* فالکون · پوسته‌ی فارسی — هسته v2
   در main world صفحه اجرا می‌شود و از گیت‌هاب به‌روز می‌شود.
   ۱) توکن‌ها و طراحی از content.css روی html[data-ff] سوار می‌شوند.
   ۲) تم «هماهنگ با فالکون» از data-theme خودِ سایت پیروی می‌کند.
   ۳) چیدمان RTL با آینه‌کردن قوانین left/right استایل‌شیت سایت ساخته می‌شود.
   ۴) متن‌ها و tooltipها جمله‌به‌جمله ترجمه می‌شوند؛ نسخه‌ی اصلی نگه داشته می‌شود تا خاموش‌کردن همه‌چیز را برگرداند. */
(() => {
  if (window.__ffLoaded) return;
  window.__ffLoaded = true;

  const DEFAULTS = { enabled: true, theme: "auto", translate: true, digits: true, rtl: true, motion: true };
  const root = document.documentElement;
  let S = { ...DEFAULTS };

  /* ================================================================ settings */
  const toggleAttr = (n, v) => (v ? root.setAttribute(n, "") : root.removeAttribute(n));
  const siteTheme = () => (root.getAttribute("data-theme") === "dark" ? "dark" : "light");
  const resolvedTheme = () => (S.theme === "dark" || S.theme === "night" ? "dark" : S.theme === "light" || S.theme === "day" ? "light" : siteTheme());

  function applyTheme(animate) {
    const t = resolvedTheme();
    if (root.getAttribute("data-ff-theme") === t) return;
    if (animate && S.motion) {
      root.setAttribute("data-ff-switching", "");
      clearTimeout(applyTheme.t);
      applyTheme.t = setTimeout(() => root.removeAttribute("data-ff-switching"), 520);
    }
    root.setAttribute("data-ff-theme", t);
  }
  function applyAttrs(animate) {
    const on = S.enabled;
    toggleAttr("data-ff", on);
    toggleAttr("data-ff-rtl", on && S.rtl);
    toggleAttr("data-ff-motion", on && S.motion);
    toggleAttr("data-ff-tr", on && S.translate);
    applyTheme(animate);
  }
  function onSettings(next, first) {
    const prev = S;
    S = { ...DEFAULTS, ...next };
    applyAttrs(!first);
    if (S.enabled && S.rtl) flipper.start();
    const textChanged = first || prev.enabled !== S.enabled || prev.translate !== S.translate || prev.digits !== S.digits || prev.rtl !== S.rtl;
    if (textChanged) {
      translator.restoreAll();
      if (S.enabled && (S.translate || S.digits)) translator.start(); else translator.stop();
    }
  }
  // تم سایت عوض شد ← اگر روی «هماهنگ» هستیم دنبالش برو
  new MutationObserver(() => { if (S.enabled) applyTheme(true); }).observe(root, { attributes: true, attributeFilter: ["data-theme"] });

  /* ================================================================ RTL flipper */
  const flipper = (() => {
    const done = new WeakSet();
    let styleEl = null, started = false;
    const SWAP = {
      left: "right", right: "left",
      "margin-left": "margin-right", "margin-right": "margin-left",
      "padding-left": "padding-right", "padding-right": "padding-left",
      "border-left-width": "border-right-width", "border-right-width": "border-left-width",
      "border-left-style": "border-right-style", "border-right-style": "border-left-style",
      "border-left-color": "border-right-color", "border-right-color": "border-left-color",
      "border-top-left-radius": "border-top-right-radius", "border-top-right-radius": "border-top-left-radius",
      "border-bottom-left-radius": "border-bottom-right-radius", "border-bottom-right-radius": "border-bottom-left-radius",
    };
    const RESET = (p) => (p === "left" || p === "right" ? "auto" : p.endsWith("-style") ? "none" : p.endsWith("-color") ? "currentcolor" : "0");
    const PREFIX = "html[data-ff-rtl] ";
    function splitSel(sel) {
      const out = []; let d = 0, cur = "";
      for (const ch of sel) {
        if (ch === "(" || ch === "[") d++;
        if (ch === ")" || ch === "]") d--;
        if (ch === "," && d === 0) { out.push(cur.trim()); cur = ""; } else cur += ch;
      }
      if (cur.trim()) out.push(cur.trim());
      return out;
    }
    function mirror(r) {
      const st = r.style; if (!st) return "";
      const decl = {}; let touched = false;
      for (let i = 0; i < st.length; i++) {
        const p = st[i];
        if (p === "text-align" || p === "float" || p === "clear") {
          const v = st.getPropertyValue(p).trim();
          if (v === "left" || v === "right") { decl[p] = v === "left" ? "right" : "left"; touched = true; }
          continue;
        }
        const q = SWAP[p]; if (!q) continue;
        const v = st.getPropertyValue(p).trim(), other = st.getPropertyValue(q).trim();
        if (other && other === v) continue;
        if ((p === "left" || p === "right") && v === "50%") continue;
        const imp = st.getPropertyPriority(p) ? " !important" : "";
        decl[q] = v + imp;
        if (!other) decl[p] = RESET(p) + imp;
        touched = true;
      }
      if (!touched) return "";
      const sels = splitSel(r.selectorText).filter((s) => !/^(html|:root|body)\b/.test(s)).map((s) => PREFIX + s);
      if (!sels.length) return "";
      return `${sels.join(",")}{${Object.entries(decl).map(([k, v]) => `${k}:${v}`).join(";")}}`;
    }
    function walk(rules) {
      let css = "";
      for (const r of rules) {
        if (r.selectorText !== undefined && r.style) css += mirror(r);
        else if (r.media && r.cssRules) { const inner = walk(r.cssRules); if (inner) css += `@media ${r.media.mediaText}{${inner}}`; }
        else if (r.cssRules && r.constructor.name === "CSSSupportsRule") { const inner = walk(r.cssRules); if (inner) css += `@supports ${r.conditionText}{${inner}}`; }
        else if (r.cssRules && r.constructor.name === "CSSLayerBlockRule") css += walk(r.cssRules);
      }
      return css;
    }
    function scan() {
      let css = "";
      for (const sh of document.styleSheets) {
        if (done.has(sh)) continue;
        const id = sh.ownerNode && sh.ownerNode.id;
        if (id && (id.startsWith("ff-") || id.startsWith("fx-"))) continue;
        let rules; try { rules = sh.cssRules; } catch (e) { continue; }
        if (!rules) continue;
        done.add(sh);
        css += walk(rules);
      }
      if (!css) return;
      if (!styleEl) { styleEl = document.createElement("style"); styleEl.id = "ff-rtl"; (document.head || root).appendChild(styleEl); }
      styleEl.textContent += css;
    }
    function start() {
      if (started) { scan(); return; }
      started = true;
      const kick = () => scan();
      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", kick, { once: true }); else kick();
      window.addEventListener("load", kick, { once: true });
      new MutationObserver((ms) => {
        for (const m of ms) for (const n of m.addedNodes) {
          if (n.nodeName === "LINK") n.addEventListener("load", kick, { once: true });
          if (n.nodeName === "STYLE" && !(n.id || "").startsWith("ff-")) setTimeout(kick, 0);
        }
      }).observe(root, { childList: true, subtree: true });
    }
    return { start };
  })();

  /* ================================================================ translator */
  const translator = (() => {
    const DICT = window.FF_DICT || {}, PARTS = window.FF_PARTS || {}, DAYS = window.FF_DAYS || {}, MONTHS = window.FF_MONTHS || {};
    const FA = "۰۱۲۳۴۵۶۷۸۹", LRI = "⁦", PDI = "⁩";
    const SKIP = "script,style,noscript,textarea,input,code,pre,[contenteditable],.ff-skip";
    const PLAT = "SUPERAPP_SUPERMARKET|SUPERAPP|PWA|PSA_ANDROID|PSA_IOS|Fidilio|IRANCELL|OUTBOX|AP|PROCUREMENT|SABA";
    const recs = new WeakMap(), touched = new Set();
    const arecs = new WeakMap(), atouched = new Set();
    const ATTRS = ["title", "placeholder", "aria-label"];
    let mo = null, queue = new Set(), raf = 0, ready = false, running = false;

    const norm = (s) => s.toLowerCase().replace(/\s+/g, " ").trim();
    const d = (s) => DICT[norm(s)];
    const iso = (a) => (/[A-Za-z]/.test(a) && !/[؀-ۿ]/.test(a) ? LRI + a + PDI : a);
    const tr = (s) => { const x = T(s); return x === s ? iso(s) : x; };   // ترجمه یا ایزوله‌ی نام لاتین
    const unit = (u) => ({ s: "ثانیه", m: "دقیقه", h: "ساعت", d: "روز", w: "هفته" }[u.toLowerCase()] || u);
    const mag = (u) => ({ million: "میلیون", billion: "میلیارد", thousand: "هزار" }[u.toLowerCase()] || u);
    const lvl = (x) => ({ low: "کم", medium: "متوسط", high: "زیاد", critical: "بحرانی" }[x.toLowerCase()] || x);
    const metric = (m) => ({ "cr": "CR", "order rate": "نرخ سفارش", "conversion": "نرخ تبدیل", "e2e cr": "E2E CR", "end-to-end cr": "CR سرتاسری" }[m.toLowerCase()] || m);
    const day = (x) => DAYS[x.toLowerCase()] || x;
    const month = (x) => MONTHS[x.toLowerCase().slice(0, 3)] || x;
    const orders = (s) => s.replace(/about (\S+) orders/i, "حدود $1 سفارش").replace(/(\S+) orders/i, "$1 سفارش").replace(/, /g, "، ");
    const part = (p) => PARTS[norm(p)] || d(p) || p;

    /* الگوهای جمله — به ترتیب اولویت */
    const R = [];
    const r = (re, fn) => R.push([re, fn]);
    r(/^(.+) · Falcon$/, (m, a) => `${T(a)} · فالکون`);
    r(/^Falcon \| SnappFood$/i, () => "فالکون | اسنپ‌فود");
    // مرکز کنترل
    r(/^Conversion is (near|below|above|well below|well above|far below|far above) its usual level(?:: (.+))?$/i, (m, l, rest) => {
      const L = { near: "نزدیک سطح معمول است", below: "پایین‌تر از سطح معمول است", above: "بالاتر از سطح معمول است", "well below": "خیلی پایین‌تر از سطح معمول است", "well above": "خیلی بالاتر از سطح معمول است", "far below": "خیلی پایین‌تر از سطح معمول است", "far above": "خیلی بالاتر از سطح معمول است" }[l.toLowerCase()];
      return `نرخ تبدیل ${L}` + (rest ? `: ${T(rest)}` : "");
    });
    r(/^(.+?) against (.+?) usual · (.+?) orders$/i, (m, a, b, c) => `${a} در برابر ${b} معمول · ${c} سفارش`);
    r(/^(CR|Order rate|Conversion|E2E CR|End-to-End CR) (.+?) against (.+?) usual \((.+?) points? (lower|higher), (.+?) sessions\)$/i,
      (m, k, a, b, c, dir, n) => `${metric(k)} ${a} در برابر ${b} معمول (${c} واحد ${dir.toLowerCase() === "lower" ? "کمتر" : "بیشتر"}، ${n} سشن)`);
    r(/^It has been off for (\d+) days?, since (.+)$/i, (m, n, dt) => `${n} روز است که از حالت معمول خارج شده؛ از ${dt}`);
    r(/^The (drop|rise) comes from (.+) \(([^()]+)\)$/i, (m, k, a, b) => `${k.toLowerCase() === "drop" ? "افت" : "رشد"} از ${tr(a)} است (${orders(b)})`);
    r(/^Look first at: (.+) \(([^()]+?) orders\)(?:, plus (\d+) more)?$/i, (m, a, n, k) => `اول اینجا را ببین: ${T(a)} (${n} سفارش)` + (k ? `، و ${k} مورد دیگر` : ""));
    r(/^(.+?) converts (below|above) its usual level$/i, (m, a, k) => `${tr(a)} ${k.toLowerCase() === "below" ? "پایین‌تر" : "بالاتر"} از سطح معمولش تبدیل می‌کند`);
    r(/^(.+?) orders lost \(about (.+?) (million|billion) toman\)$/i, (m, n, a, u) => `${n} سفارش از دست رفت (حدود ${a} ${mag(u)} تومان)`);
    r(/^(.+?) orders lost$/i, (m, n) => `${n} سفارش از دست رفت`);
    r(/^(.+?) orders lost · about (.+?) (million|billion) toman · (.+)$/i, (m, n, a, u, o) => `${n} سفارش از دست رفت · حدود ${a} ${mag(u)} تومان · ${T(o)}`);
    r(/^between (.+?) (billion|million) toman and (.+?) (billion|million) toman$/i, (m, a, u, b, u2) => `بین ${a} ${mag(u)} و ${b} ${mag(u2)} تومان`);
    r(/^(.+?) (billion|million) toman$/i, (m, a, u) => `${a} ${mag(u)} تومان`);
    r(/^([\d.,]+[KMB]?) toman$/i, (m, a) => `${a} تومان`);
    r(/^(.+?)× avg basket$/i, (m, a) => `${a}× میانگین سبد`);
    r(/^(\d+) earlier (Mon|Tues|Wednes|Thurs|Fri|Satur|Sun)days$/i, (m, n, x) => `${n} ${day(x.slice(0, 3))} قبل`);
    r(/^(.+?) noise units: inside everyday swing$/i, (m, a) => `${a} واحد نوسان: داخل نوسان روزمره`);
    r(/^(.+?) noise units: (.+)$/i, (m, a, b) => `${a} واحد نوسان: ${T(b)}`);
    r(/^(.+?) reached$/i, (m, a) => `${a} رسیده`);
    r(/^Variation (\d+)$/i, (m, n) => `واریانت ${n}`);
    r(/^([^A-Za-z]+): (.+?) close-cart sessions, (.+)$/i, (m, dt, a, b) => `${dt}: ${a} سشن Close Cart، ${b}`);
    r(/^close-cart sessions \/ all sessions, usual = (\d+) days$/i, (m, n) => `سشن‌های Close Cart / همه‌ی سشن‌ها، معمول = ${n} روز`);
    r(/^· about (.+?) (million|billion) toman$/i, (m, a, u) => `· حدود ${a} ${mag(u)} تومان`);
    r(/^about (.+?) (million|billion|thousand) toman$/i, (m, a, u) => `حدود ${a} ${mag(u)} تومان`);
    r(/^about (.+?) (million|billion|thousand)$/i, (m, a, u) => `حدود ${a} ${mag(u)}`);
    r(/^about (.+?) orders$/i, (m, a) => `حدود ${a} سفارش`);
    r(/^between (.+?) (billion|million) toman and (.+?) (billion|million) toman · avg order (.+?) toman$/i,
      (m, a, u, b, u2, c) => `بین ${a} ${mag(u)} و ${b} ${mag(u2)} تومان · میانگین سفارش ${c} تومان`);
    r(/^usual (.+?) · z (.+?) · confidence (low|medium|high)$/i, (m, a, z, c) => `معمول ${a} · z ${z} · اطمینان ${lvl(c)}`);
    r(/^expected (.+?) · at risk (.+)$/i, (m, a, b) => `انتظار ${a} · در خطر ${b}`);
    r(/^normal (.+?) to (.+)$/i, (m, a, b) => `بازه‌ی معمول ${a} تا ${b}`);
    r(/^inside the normal range, nothing at risk$/i, () => "داخل بازه‌ی معمول؛ چیزی در خطر نیست");
    r(/^outside the normal range(.*)$/i, (m, x) => `خارج از بازه‌ی معمول${T(x)}`);
    r(/^Record: (.+?) on (.+?), the best of (\d+) complete days$/i, (m, a, b, n) => `رکورد: ${a} در ${b}؛ بهترین در میان ${n} روز کامل`);
    r(/^(.+?) pt to go$/i, (m, a) => `${a} واحد تا رکورد`);
    r(/^(.+?) pt vs usual (.+)$/i, (m, a, b) => `${a} pt نسبت به معمولِ ${b}`);
    r(/^(.+?) vs usual (.+)$/i, (m, a, b) => `${a} نسبت به معمولِ ${b}`);
    r(/^vs usual (.+)$/i, (m, b) => `نسبت به معمولِ ${b}`);
    r(/^vs yesterday$/i, () => "نسبت به دیروز");
    r(/^vs last (\w+)$/i, (m, x) => `نسبت به ${day(x)} گذشته`);
    r(/^(\(?)([+−-]?[\d.,]+ ?(?:pp|pt|%)) vs previous period(\)?)$/i, (m, o, a, c) => `${o}${a} نسبت به دوره‌ی قبل${c}`);
    r(/^vs previous period$/i, () => "نسبت به دوره‌ی قبل");
    r(/^vs baseline$/i, () => "نسبت به خط پایه");
    r(/^([−+-]?[\d.,]+ ?%) vs baseline$/i, (m, a) => `${a} نسبت به خط پایه`);
    r(/^baseline (.+)$/i, (m, a) => `خط پایه ${a}`);
    r(/^([−+-][\d.,]+) orders$/i, (m, a) => `${a} سفارش`);
    r(/^(rate|mix) effect, (.+)$/i, (m, k, a) => `اثر ${k.toLowerCase() === "rate" ? "نرخ" : "ترکیب"}، ${a}`);
    r(/^rate effect (.+?) · mix effect (.+)$/i, (m, a, b) => `اثر نرخ ${a} · اثر ترکیب ${b}`);
    r(/^Updated (\d+)\s?([smhdw]) ago$/i, (m, n, u) => `${n} ${unit(u)} پیش به‌روز شد`);
    r(/^Updated just now$/i, () => "همین الان به‌روز شد");
    r(/^(\d+)\s?([smhdw]) ago$/i, (m, n, u) => `${n} ${unit(u)} پیش`);
    r(/^data stored (.+)$/i, (m, a) => `داده ذخیره شد ${T(a)}`);
    r(/^(\d{1,2}:\d{2}) ?(AM|PM)$/i, (m, t, ap) => `${t} ${ap.toUpperCase() === "AM" ? "ق.ظ" : "ب.ظ"}`);
    r(/^Variation (\d+) vs control: (.+?), (no clear difference|better|worse)$/i, (m, n, a, k) => `واریانت ${n} در برابر کنترل: ${a}، ${d(k)}`);
    r(/^control (.+?) · (v\d+) (.+)$/i, (m, a, v, b) => `کنترل ${a} · ${v} ${b}`);
    r(/^\+(\d+) more$/i, (m, n) => `+${n} مورد دیگر`);
    r(/^Show (\d+) more$/i, (m, n) => `نمایش ${n} مورد دیگر`);
    r(/^Show more \((\d+)\)$/i, (m, n) => `بیشتر (${n})`);
    r(/^(Active|Resolved|All|Open|Done|Overdue|Cancelled) (\d+)$/i, (m, k, n) => `${d(k) || ({ active: "فعال", resolved: "حل‌شده" }[k.toLowerCase()] || k)} ${n}`);
    r(/^(\d+) resolved in total$/i, (m, n) => `${n} مورد حل‌شده در مجموع`);
    r(/^· (\d+) days running$/i, (m, n) => `· ${n} روز پیاپی`);
    r(/^(\d+) behavioral alerts? in this window$/i, (m, n) => `${n} هشدار رفتاری در این بازه`);
    r(/^Biggest drop-off: (.+?) → (.+)$/i, (m, a, b) => `بیشترین ریزش: ${tr(a)} → ${tr(b)}`);
    r(/^(.+?) of (.+?) do not proceed$/i, (m, a, g) => `${a} از ${T(g)} جلوتر نمی‌روند`);
    r(/^(.+?) of (.+?) do not reach (.+)$/i, (m, a, g, x) => `${a} از ${T(g)} به ${T(x)} نمی‌رسند`);
    r(/^Overall CR \((Close Cart|Gross|close cart)\) is (.+?), (up|down) (.+?) vs previous period$/i,
      (m, k, a, ud, b) => `CR کلی (${/gross/i.test(k) ? "ناخالص" : "Close Cart"}) ${a} است؛ ${b} ${ud.toLowerCase() === "up" ? "بیشتر" : "کمتر"} از دوره‌ی قبل`);
    r(/^(End-to-End CR|E2E CR) is (.+?), (up|down) (.+?) vs previous period$/i, (m, k, a, ud, b) => `${metric(k)} ${a} است؛ ${b} ${ud.toLowerCase() === "up" ? "بیشتر" : "کمتر"} از دوره‌ی قبل`);
    r(/^(End-to-End CR|E2E CR) (fell|rose) (.+?) vs previous period$/i, (m, k, fr, a) => `${metric(k)} نسبت به دوره‌ی قبل ${a} ${fr.toLowerCase() === "fell" ? "کاهش" : "افزایش"} یافت`);
    r(/^(End-to-End CR|E2E CR) is (.+?) \((.+?) previously\)$/i, (m, k, a, b) => `${metric(k)} ${a} است (${b} در دوره‌ی قبل)`);
    r(/^(.+?) has high traffic but below-benchmark conversion$/i, (m, a) => `${iso(a)} ترافیک بالایی دارد اما نرخ تبدیلش زیر معیار است`);
    r(/^(.+?) holds (.+?) of traffic at (.+?) CR vs (.+?) benchmark \(gap (.+?)\)$/i, (m, a, b, c, e, g) => `${iso(a)} ${b} از ترافیک را با CR ${c} در برابر معیار ${e} دارد (فاصله ${g})`);
    r(/^This transition is (.+?) of all funnel loss \((.+?) sessions\)$/i, (m, a, b) => `این مرحله ${a} از کل ریزش قیف است (${b} سشن)`);
    r(/^(.+?) sessions lost here$/i, (m, n) => `${n} سشن اینجا از دست رفت`);
    r(/^Anomaly in end to end cr on (.+)$/i, (m, a) => `ناهنجاری در CR سرتاسری در ${a}`);
    r(/^(Lunch|Dinner|Morning|Overnight) converts best at (.+?) E2E CR; (Lunch|Dinner|Morning|Overnight) worst at (.+?); peak hour (.+)$/i,
      (m, a, b, c, e, h) => `${d(a)} با E2E CR ${b} بهترین بخش روز است؛ ${d(c)} با ${e} ضعیف‌ترین؛ ساعت اوج ${h}`);
    r(/^Hourly data covers (.+?) → (.+)$/i, (m, a, b) => `داده‌ی ساعتی از ${a} تا ${b} را پوشش می‌دهد`);
    r(/^(.+?) carousel$/i, (m, a) => `کاروسل ${iso(a)}`);
    r(/^· (.+)$/, (m, a) => { const x = T(a); return x === a ? null : `· ${x}`; });
    r(/^· Trough (.+)$/i, (m, a) => `· کمینه ${a}`);
    r(/^Peak (.+)$/i, (m, a) => `اوج ${a}`);
    r(/^w\/c (\d+) (\w{3})$/i, (m, n, mo) => `هفته‌ی ${n} ${month(mo)}`);
    r(/^, (.+?) ordered$/i, (m, a) => `، ${a} سفارش دادند`);
    r(/^(.+?)\. Sessions credited to this macro's entry clicks, then each step$/i, (m, a) => `${a}. سشن‌هایی که به کلیک‌های ورود این ماکرو نسبت داده شده‌اند، سپس هر مرحله`);
    r(/^Sessions credited to this macro's entry clicks, then each step$/i, () => "سشن‌هایی که به کلیک‌های ورود این ماکرو نسبت داده شده‌اند، سپس هر مرحله");
    r(/^Sessions, orders and conversion of the macro's own entry page$/i, () => "سشن، سفارش و نرخ تبدیلِ صفحه‌ی ورودِ خود ماکرو");
    r(/^Basis: where its cards lead \(product page, vendor menu, or a hub\)$/i, () => "مبنا: کارت‌هایش به کجا می‌روند (صفحه‌ی محصول، منوی فروشنده یا یک هاب)");
    r(/^(.+?) of previous(?: step)?$/i, (m, a) => `${a} از مرحله‌ی قبل`);
    r(/^(.+?) of impressions$/i, (m, a) => `${a} از Impressionها`);
    r(/^only (.+?) continue$/i, (m, a) => `فقط ${a} ادامه می‌دهند`);
    r(/^(.+?) · (.+?) continue$/i, (m, a, b) => `${T(a)} · ${b} ادامه می‌دهند`);
    r(/^By carousel title and city \(top (\d+) of (.+?)\)$/i, (m, n, t) => `بر اساس عنوان کاروسل و شهر (${n} مورد برتر از ${t})`);
    r(/^\(latest: (.+)\)$/i, (m, a) => `(آخرین: ${a})`);
    r(/^Conversion (.+?) → (.+?), mostly at (.+?)(?: \((.+?) sessions\))?$/i, (m, a, b, s, n) => `نرخ تبدیل ${a} → ${b}؛ بیشتر در ${T(s)}` + (n ? ` (${n} سشن)` : ""));
    r(new RegExp(`^(.+?) on (${PLAT}): (.+?) → (.+?), (.+?) orders, q (.+)$`, "i"), (m, a, p, b, c, o, q) => `${tr(a)} روی ${p}: ${b} → ${c}، ${o} سفارش، q ${q}`);
    r(new RegExp(`^(.+?) on (${PLAT})$`, "i"), (m, a, p) => `${tr(a)} روی ${p}`);
    r(new RegExp(`^(${PLAT}) / (\\S+): (.+?) of (.+?) sessions(?:, (.+?) pt vs previous 7 days)?$`, "i"), (m, p, e, a, n, c) => `${p} / ${e}: ${a} از ${n} سشن` + (c ? `، ${c} pt نسبت به ۷ روز قبل` : ""));
    r(new RegExp(`^(${PLAT}): (.+?) sessions$`, "i"), (m, p, n) => `${p}: ${n} سشن`);
    r(/^(\d+) (platforms|citys|cities) under (\d+) sessions are not ranked$/i, (m, n, k, s) => `${n} ${/plat/i.test(k) ? "پلتفرم" : "شهر"} با کمتر از ${s} سشن رتبه‌بندی نشدند`);
    r(/^(\d+) cities$/i, (m, n) => `${n} شهر`);
    r(/^(.+?) of sessions$/i, (m, a) => `${a} از سشن‌ها`);
    r(/^(.+?) \(platforms with ([\d,]+)\+ sessions\)$/i, (m, a, b) => `${a} (پلتفرم‌های بالای ${b} سشن)`);
    r(/^(\d+) small values: (.+)$/i, (m, n, b) => `${n} مقدار کوچک: ${b}`);
    r(/^Where "(.+)" comes from$/i, (m, a) => `منبع داده‌ی «${T(a)}»`);
    r(/^(.+?): open the detail$/i, (m, a) => `${T(a)}: جزئیات`);
    r(/^of (.+?) yesterday$/i, (m, a) => `از ${a} دیروز`);
    r(/^yesterday (.+)$/i, (m, a) => `دیروز ${a}`);
    r(/^toman, estimate$/i, () => "تومان، تخمینی");
    r(/^Data through (.+?) · Read live from the local store$/i, (m, a) => `داده تا ${a} · مستقیم از ذخیره‌ی محلی`);
    r(/^Click to refresh$/i, () => "برای به‌روزرسانی کلیک کنید");
    r(/^Standard data: (.+?) → (.+?) \((\d+) days\)$/i, (m, a, b, n) => `داده‌ی استاندارد: ${a} تا ${b} (${n} روز)`);
    r(/^Uses only the (\d+) of (\d+) days that have order counts$/i, (m, a, b) => `فقط ${a} روز از ${b} روزی که شمار سفارش دارند استفاده شده`);
    r(/^Gross orders ÷ (valid|total) sessions(.*)$/i, (m, k, rest) => `سفارش ناخالص ÷ ${k.toLowerCase() === "valid" ? "سشن معتبر" : "کل سشن‌ها"}${rest.replace(/ — the headline platform funnel metric/i, " — شاخص اصلی قیف پلتفرم")}`);
    r(/^Net orders ÷ gross orders \(order quality \/ cancellation guardrail\)$/i, () => "سفارش خالص ÷ سفارش ناخالص (کیفیت سفارش / حفاظ لغو)");
    r(/^Latest day \((.+?)\) vs the prior 10-day average$/i, (m, a) => `آخرین روز (${a}) در برابر میانگین ۱۰ روز قبل`);
    r(/^Thresholds: (.+?) rates, (.+?) counts$/i, (m, a, b) => `آستانه‌ها: ${a} برای نرخ‌ها، ${b} برای شمارش‌ها`);
    r(/^vs the prior 10-day average, Overall CR \(close cart\) is (.+?) \((.+?)\)$/i, (m, a, b) => `در برابر میانگین ۱۰ روز قبل، CR کلی (Close Cart) ${a} است (${b})`);
    r(/^(\d+) metrics moved past threshold$/i, (m, n) => `${n} شاخص از آستانه گذشت`);
    r(/^(.+?), against the (\d+) days before$/i, (m, a, n) => `${a}، در برابر ${n} روز قبل از آن`);
    r(/^(.+?) sessions with an entry click, (.+?) without one \(ordered (.+?)\)$/i, (m, a, b, c) => `${a} سشن با کلیک ورود، ${b} بدون آن (${c} سفارش)`);
    r(/^Open a macro for its entry points$/i, () => "برای دیدن نقاط ورود، یک ماکرو را باز کنید");
    r(/^From (.+?) to (.+?): (\d+) of (\d+) days stored$/i, (m, a, b, c, n) => `از ${a} تا ${b}: ${c} از ${n} روز ذخیره شده`);
    r(/^(\d+) not settled yet$/i, (m, n) => `${n} روز هنوز نهایی نشده`);
    r(/^(\d+) days missing$/i, (m, n) => `${n} روز ناقص`);
    r(/^(\d+) rows$/i, (m, n) => `${n} ردیف`);
    r(/^Orders [−-](\d+)%, sessions [−-](\d+)% \(all platforms\)$/i, (m, a, b) => `سفارش −${a}٪، سشن −${b}٪ (همه‌ی پلتفرم‌ها)`);
    r(/^(Sun|Mon|Tue|Wed|Thu|Fri|Sat) (\d{4}-\d{2}-\d{2})$/i, (m, x, dt) => `${day(x)} ${dt}`);
    r(/^(\d+) (days|day)$/i, (m, n) => `${n} روز`);
    r(/^City (\d+)$/i, (m, n) => `شهر ${n}`);
    r(/^(\d+) sessions$/i, (m, n) => `${n} سشن`);
    r(/^([^A-Za-z]+?) to ([^A-Za-z]+)$/, (m, a, b) => `${a} تا ${b}`);
    r(/^([A-Za-z][^,]+?), ([^A-Za-z]+)$/, (m, a, b) => { const A = T(a); return A === a ? null : `${A}، ${b}`; });
    r(/^(.+?) \((.+?)\) vs$/i, (m, a, b) => `${T(a)} (${b}) در برابر`);
    r(/^(.+?) sessions lost between (.+?) and (.+)$/i, (m, n, a, b) => `${n} سشن بین ${T(a)} و ${T(b)} از دست رفت`);
    r(/^(.+?) · (high|medium|low|critical)(?: · (.+))?$/i, (m, a, l, rest) => `${tr(a)} · ${lvl(l)}` + (rest ? ` · ${T(rest)}` : ""));
    r(/^(.+?) → (.+)$/, (m, a, b) => { const A = T(a), B = T(b); return A !== a || B !== b ? `${A === a ? iso(a) : A} → ${B === b ? iso(b) : B}` : null; });
    r(/^(.+?) \(([^()]+)\)$/, (m, a, b) => { const A = T(a); if (A === a) return null; const B = T(b); return `${A} (${B === b ? iso(b) : B})`; });
    r(/^([A-Za-z][^:]{2,40}): (.+)$/, (m, a, b) => { const A = T(a); if (A === a) return null; return `${A}: ${T(b)}`; });
    // برچسب نقطه‌ی ورود: «Vendor card · Search»
    r(/^([A-Za-z][A-Za-z &()\-]+?) · ([A-Za-z][A-Za-z &()\-]+)$/, (m, a, b) => {
      const A = PARTS[norm(a)], B = PARTS[norm(b)];
      return A && B ? `${A} · ${B}` : null;
    });

    const FRAGS = [
      [/\bvs yesterday\b/gi, "نسبت به دیروز"],
      [/\bvs last (\w+)\b/gi, (m, x) => `نسبت به ${day(x)} گذشته`],
      [/\bvs previous period\b/gi, "نسبت به دوره‌ی قبل"],
      [/\bvs previous 7 days\b/gi, "نسبت به ۷ روز قبل"],
      [/\bsource:/gi, "منبع:"],
      [/\bdata stored\b/gi, "داده ذخیره شد"],
      [/(\d)\s?AM\b/g, "$1 ق.ظ"], [/(\d)\s?PM\b/g, "$1 ب.ظ"],
      [/(\d[\d.,]*[KMB]?) sessions\b/g, "$1 سشن"],
      [/(\d[\d.,]*[KMB]?) orders\b/g, "$1 سفارش"],
      [/\bowner: unassigned\b/gi, "مالک: بدون مالک"],
      [/\bpartial day\b/gi, "روز ناقص"],
      [/\busual = (\d+) days\b/gi, "معمول = $1 روز"],
    ];

    const SPLIT = /(?<=[.!?])\s+(?=[A-Z0-9“"(⁦])/;
    function rule(s) {
      for (const [re, fn] of R) {
        const m = s.match(re);
        if (m) { const out = fn(...m); if (out != null) return out; }
      }
      return null;
    }
    // ترجمه‌ی یک متن (جمله یا چند جمله)
    function T(s) {
      if (!s || !/[A-Za-z]/.test(s)) return s;
      const hit = d(s);
      if (hit) return hit;
      const parts = s.split(SPLIT);
      if (parts.length > 1) {
        const out = parts.map((p) => T(p));
        return out.some((x, i) => x !== parts[i]) ? out.join(" ") : s;
      }
      const end = s.match(/[.:]$/) ? s.slice(-1) : "";
      const core = end ? s.slice(0, -1) : s;
      const hit2 = end && d(core);
      if (hit2) return hit2 + (end === "." ? "." : ":");
      const ru = rule(core);
      if (ru != null) return ru + end;
      let out = s;
      for (const [re, rep] of FRAGS) out = out.replace(re, rep);
      return out;
    }

    function faNum(s) {
      return s.replace(/([+\-−▲▼]\s?)?(\d{1,3}(?:,\d{3})+|\d+)(\.\d+)?(\s?(?:%|pp|pt|[KMBk]|x)(?![A-Za-z]))?/g, (m, sign, int, frac, u, off, str) => {
        const prev = str[off - 1] || "";
        if (/[A-Za-z_\/#@:-]/.test(prev) && !(prev === "-" && sign)) return m;   // meal41، v1، w/c، 2026-11-01
        if (/\d{4}-\d{2}/.test(str.slice(off, off + 7))) return m;              // تاریخ ISO دست‌نخورده
        const next = str[off + m.length] || "";
        if (/[A-Za-z_]/.test(next) && !u) return m;
        let out = (sign || "") + int.replace(/,/g, "٬").replace(/\d/g, (x) => FA[x]);
        if (frac) out += "٫" + frac.slice(1).replace(/\d/g, (x) => FA[x]);
        if (u) out += u.trim() === "%" ? "٪" : u;
        return sign || (u && u.trim() !== "%") ? LRI + out + PDI : out;
      });
    }
    // علائم نگارشی فارسی وقتی متن فارسی است
    function punct(s) {
      if (!/[؀-ۿ]/.test(s.replace(/[۰-۹٫٬٪]/g, ""))) return s;
      let o = s.replace(/,(?=\s)/g, "،").replace(/;(?=\s)/g, "؛").replace(/\?(?=\s|$)/g, "؟");
      if (S.rtl) o = o.replace(/→/g, "←");
      return o;
    }

    function transform(src, inSvg) {
      const lead = src.match(/^\s*/)[0], trail = src.match(/\s*$/)[0];
      let core = src.trim();
      if (!core) return src;
      if (S.translate && /[A-Za-z]/.test(core)) {
        if (S.rtl && core === "«") core = "»"; else if (S.rtl && core === "»") core = "«";
        core = T(core);
        core = punct(core);
      }
      if (S.digits && /\d/.test(core)) core = faNum(core);
      if (inSvg !== "title" && !inSvg && S.rtl && /[A-Za-z]/.test(core) && !/[؀-ۿ]/.test(core) && /[\s.,:;()?!→·-]/.test(core) && !core.startsWith(LRI)) core = LRI + core + PDI;
      return lead + core + trail;
    }

    function setNode(node, val) {
      const rec = recs.get(node);
      recs.set(node, { src: rec ? rec.src : node.nodeValue, out: val });
      touched.add(node);
      node.nodeValue = val;
    }
    function processText(node) {
      const p = node.parentElement;
      if (!p || p.closest(SKIP)) return;
      const cur = node.nodeValue, rec = recs.get(node);
      if (rec && cur === rec.out) return;
      const out = transform(cur, p.tagName === "TITLE" ? "title" : !!p.closest("svg"));
      if (out !== cur) { recs.set(node, { src: cur, out }); touched.add(node); node.nodeValue = out; }
      else if (rec) { recs.delete(node); touched.delete(node); }
    }
    function processAttrs(el) {
      if (!S.translate && !S.digits) return;
      for (const a of ATTRS) {
        if (!el.hasAttribute(a)) continue;
        const cur = el.getAttribute(a);
        let map = arecs.get(el); if (!map) { map = {}; arecs.set(el, map); }
        if (map[a] && map[a].out === cur) continue;
        const out = transform(cur, false);
        if (out !== cur) { map[a] = { src: cur, out }; atouched.add(el); el.setAttribute(a, out); }
      }
    }
    const NUMRUN = /^\s*[▲▼+\-−]?\s*[0-9۰-۹][0-9۰-۹٫٬.,:]*\s*(pt|pp|%|٪|K|M|B|k|x)?\s*$/;
    function isolateRuns(el) {
      if (!S.digits || !el || el.nodeType !== 1) return;
      let run = [];
      const flush = () => {
        if (run.length > 1) {
          const all = run.map((n) => n.nodeValue).join("");
          const txt = all.replace(/[⁦⁩]/g, "");
          const m = txt.match(NUMRUN);
          if (m && (/[▲▼+\-−]/.test(txt) || (m[1] && !/[%٪]/.test(m[1])))) {
            const first = run[0], last = run[run.length - 1];
            if (!(first.nodeValue.startsWith(LRI) && last.nodeValue.endsWith(PDI) && txt.length + 2 === all.length)) {
              run.forEach((n) => { const v = n.nodeValue.replace(/[⁦⁩]/g, ""); if (v !== n.nodeValue) setNode(n, v); });
              setNode(first, LRI + first.nodeValue);
              setNode(last, last.nodeValue + PDI);
            }
          }
        }
        run = [];
      };
      for (const c of el.childNodes) { if (c.nodeType === 3) run.push(c); else if (c.nodeType !== 8) flush(); }
      flush();
    }
    // جمله‌ای که ری‌اکت در چند text node شکسته («control 32.5% · v» «1» « 32.5%»): یکجا ترجمه می‌شود
    const joined = new WeakSet();
    function srcOf(n) { const rec = recs.get(n); return rec && n.nodeValue === rec.out ? rec.src : n.nodeValue; }
    function tryJoin(el) {
      if (!el || el.nodeType !== 1 || !S.translate || el.closest(SKIP) || el.closest("svg")) return false;
      const kids = [...el.childNodes];
      if (kids.some((c) => c.nodeType === 1)) return false;
      const nodes = kids.filter((c) => c.nodeType === 3);
      if (nodes.length < 2) return false;
      const srcs = nodes.map(srcOf), full = srcs.join("");
      if (!/[A-Za-z]{2}/.test(full)) return false;
      const core = full.trim(), tcore = T(core);
      if (tcore === core) return false;
      const out = transform(full, el.tagName === "TITLE" ? "title" : false);
      nodes.forEach((n, i) => {
        const want = i === 0 ? out : "";
        const rec = recs.get(n);
        if (n.nodeValue !== want || !rec) { recs.set(n, { src: srcs[i], out: want }); touched.add(n); n.nodeValue = want; }
      });
      joined.add(el);
      return true;
    }
    function processTree(n) {
      if (n.nodeType === 3) {
        const p = n.parentElement;
        if (p && (joined.has(p) || [...p.childNodes].filter((c) => c.nodeType === 3).length > 1) && tryJoin(p)) return;
        processText(n); return isolateRuns(p);
      }
      if (n.nodeType !== 1) return;
      if (n.matches(SKIP)) return;
      const w = document.createTreeWalker(n, NodeFilter.SHOW_TEXT);
      const texts = []; const parents = new Set(); let x;
      while ((x = w.nextNode())) { texts.push(x); if (x.parentElement) parents.add(x.parentElement); }
      const done = new Set();
      parents.forEach((p) => { if (tryJoin(p)) done.add(p); });
      for (const t of texts) if (!done.has(t.parentElement)) processText(t);
      parents.forEach((p) => { if (!done.has(p)) isolateRuns(p); });
      if (n.hasAttribute && (n.hasAttribute("title") || n.hasAttribute("aria-label") || n.hasAttribute("placeholder"))) processAttrs(n);
      n.querySelectorAll("[title],[aria-label],[placeholder]").forEach(processAttrs);
    }
    function flush() {
      raf = 0;
      if (!running) { queue.clear(); return; }
      mo && mo.disconnect();
      for (const n of queue) if (n.isConnected) processTree(n);
      queue.clear();
      observe();
    }
    function schedule(n) { queue.add(n); if (!raf) raf = requestAnimationFrame(flush); }
    function observe() {
      if (!mo) mo = new MutationObserver((ms) => {
        for (const m of ms) {
          if (m.type === "characterData") schedule(m.target);
          else if (m.type === "attributes") schedule(m.target);
          else m.addedNodes.forEach(schedule);
        }
      });
      mo.observe(root, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    }
    function all() { processTree(document.head); processTree(document.body); }
    function begin() { ready = true; if (running) { all(); observe(); } }
    function start() {
      running = true;
      if (ready) { all(); observe(); return; }
      const go = () => setTimeout(begin, 600); // بعد از hydration ری‌اکت
      if (document.readyState === "complete") go(); else window.addEventListener("load", go, { once: true });
    }
    function stop() { running = false; mo && mo.disconnect(); }
    function restoreAll() {
      mo && mo.disconnect();
      for (const n of touched) { const rec = recs.get(n); if (rec && n.isConnected && n.nodeValue === rec.out) n.nodeValue = rec.src; recs.delete(n); }
      touched.clear();
      for (const el of atouched) { const map = arecs.get(el) || {}; for (const a in map) if (el.getAttribute(a) === map[a].out) el.setAttribute(a, map[a].src); arecs.delete(el); }
      atouched.clear();
      if (running && ready) observe();
    }
    return { start, stop, restoreAll, T };
  })();
  window.__ffT = translator.T; // برای عیب‌یابی

  /* ================================================================ boot */
  // لودر تنظیمات را در detail رویداد می‌فرستد (attribute ممکن است با hydration پاک شود)
  const readAttr = () => { try { return JSON.parse(root.getAttribute("data-fx-settings") || "null"); } catch (e) { return null; } };
  const dev = window.__ffDevSettings;
  onSettings(dev || readAttr() || DEFAULTS, true);
  document.addEventListener("fx:settings", (e) => {
    if (window.__ffDevSettings) return;
    let next = null;
    try { next = typeof e.detail === "string" ? JSON.parse(e.detail) : null; } catch (err) { /* ignore */ }
    onSettings(next || readAttr() || S, false);
  });
  document.dispatchEvent(new CustomEvent("fx:hello"));
  window.__ffSet = (patch) => onSettings({ ...S, ...patch }, false);
})();
