const DEFAULTS = { enabled: true, theme: "night", translate: true, digits: true, rtl: true, motion: true };
const store = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) || null;

function render(s) {
  document.body.classList.toggle("off", !s.enabled);
  document.querySelectorAll("input[data-k]").forEach((i) => { i.checked = !!s[i.dataset.k]; });
  document.querySelectorAll("[data-theme]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.theme === s.theme)));
}
function save(patch) {
  if (store) store.set(patch);
  current = { ...current, ...patch };
  render(current);
}

let current = { ...DEFAULTS };
if (store) store.get(DEFAULTS, (v) => { current = v; render(v); });
else render(current);

document.querySelectorAll("input[data-k]").forEach((i) => i.addEventListener("change", () => save({ [i.dataset.k]: i.checked })));
document.querySelectorAll("[data-theme]").forEach((b) => b.addEventListener("click", () => save({ theme: b.dataset.theme })));

/* ---------- به‌روزرسانی */
const FA = (s) => String(s).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
const $ = (id) => document.getElementById(id);
const btn = $("upd");
const send = (type) => new Promise((res) => chrome.runtime.sendMessage({ type }, (r) => { void chrome.runtime.lastError; res(r || {}); }));

function ago(ts) {
  if (!ts) return "";
  const m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return "همین الان";
  if (m < 60) return `${FA(m)} دقیقه پیش`;
  const h = Math.round(m / 60);
  return h < 24 ? `${FA(h)} ساعت پیش` : `${FA(Math.round(h / 24))} روز پیش`;
}
function setBtn(label, mode, disabled) {
  btn.className = "btn" + (mode === "ghost" ? " ghost" : "");
  btn.innerHTML = label; btn.disabled = !!disabled;
}
function showNotes(t) { const n = $("notes"); n.hidden = !t; n.textContent = t || ""; }

let pending = null;
async function refresh() {
  if (!chrome.runtime || !chrome.runtime.sendMessage) return;
  const st = await send("fx:status");
  $("vtitle").textContent = `نسخه‌ی پوسته ${FA(st.version || "؟")}`;
  $("vline").textContent = "در حال بررسی گیت‌هاب…";
  setBtn('<span class="spin"></span>', "", true);
  const r = await send("fx:check");
  if (r.error) {
    $("dot").className = "dot";
    $("vline").textContent = `بررسی ناموفق بود: ${r.error}`;
    setBtn("دوباره", "ghost", false); pending = "check"; return;
  }
  if (r.loaderTooOld) {
    $("dot").className = "dot new";
    $("vline").textContent = `نسخه‌ی ${FA(r.remote)} آماده است، اما به نصب دوباره‌ی افزونه (zip جدید) نیاز دارد.`;
    showNotes(r.notes); setBtn("zip جدید", "", false); pending = "zip:" + (r.zipUrl || ""); return;
  }
  if (r.available) {
    $("dot").className = "dot new";
    $("vline").textContent = `نسخه‌ی ${FA(r.remote)} منتشر شده است.`;
    showNotes(r.notes); setBtn("به‌روزرسانی", "", false); pending = "update"; return;
  }
  $("dot").className = "dot ok";
  $("vline").textContent = `آخرین نسخه نصب است · ${ago(Date.now())}`;
  showNotes(st.notes); setBtn("بررسی", "ghost", false); pending = "check";
}
btn.addEventListener("click", async () => {
  if (pending === "check") return refresh();
  if (pending && pending.startsWith("zip:")) { const u = pending.slice(4); if (u) chrome.tabs.create({ url: u }); return; }
  if (pending === "update") {
    setBtn('<span class="spin"></span> دریافت…', "", true);
    const r = await send("fx:update");
    if (r.error) { $("vline").textContent = `خطا: ${r.error}`; setBtn("دوباره", "", false); return; }
    $("dot").className = "dot ok";
    $("vtitle").textContent = `نسخه‌ی پوسته ${FA(r.version)}`;
    $("vline").textContent = r.reloaded ? `نصب شد؛ ${FA(r.reloaded)} تب فالکون تازه شد.` : "نصب شد؛ دفعه‌ی بعد که فالکون را باز کنید اعمال می‌شود.";
    setBtn("بررسی", "ghost", false); pending = "check";
  }
});
refresh();
