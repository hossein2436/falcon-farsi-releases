/* کجا دنبال نسخه‌ی جدید بگردیم */
self.FX_CONFIG = {
  owner: "hossein2436",
  repo: "falcon-farsi-releases",
  branch: "main",
  loaderVersion: 3, // اگر version.json حداقل لودر بالاتری بخواهد، باید zip جدید نصب شود
  checkEveryMinutes: 360,
};
